"""Generates the four Grafana dashboard JSON files, grafana_queries.sql and
docs/DASHBOARD_GUIDE.md from ONE set of panel definitions, so the SQL in the
dashboards, the SQL file and the documentation can never drift apart.

You do NOT need to run this; the generated files are already in the ZIP.
Run it only if you change a query:   python tools/build_dashboards.py
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DS = {"type": "mysql", "uid": "logistics-mysql"}

# ---------------------------------------------------------------- filters ---
LATEST = ("(SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' "
          "ORDER BY r.started_at DESC LIMIT 1)")
RUN = f"IF('${{run}}' = 'latest', {LATEST}, '${{run}}')"
RUN_FILTER = f"e.run_id = {RUN}"
F = (f"{RUN_FILTER}\n"
     "  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))\n"
     "  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))\n"
     "  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))\n"
     "  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))\n"
     "  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))")
OPEN = "e.order_status IN ('In Transit', 'Out for Delivery')"
TRAFFIC_ORDER = "FIELD(e.traffic_level, 'Low', 'Medium', 'High', 'Severe')"
ROUTE_ORDER = "FIELD(e.route_condition, 'Good', 'Moderate', 'Poor')"
PRIORITY_ORDER = "FIELD(e.priority, 'Express', 'Priority', 'Standard')"
VEHICLE_ORDER = "FIELD(e.vehicle_type, 'Bike', 'Van', 'Mini Truck', 'Truck')"


def q(sql: str) -> str:
    return sql.replace("{F}", F).replace("{RUN}", RUN).replace("{OPEN}", OPEN).strip()


def variables():
    def multi(name, label, sql):
        return {
            "name": name, "label": label, "type": "query", "datasource": DS,
            "query": sql, "definition": sql, "refresh": 2, "sort": 1,
            "multi": True, "includeAll": True, "allValue": "'__ALL__'",
            "current": {"selected": True, "text": ["All"], "value": ["$__all"]},
            "options": [], "hide": 0,
        }
    run_sql = ("SELECT 'latest' AS __value, 'Latest run (auto)' AS __text UNION ALL "
               "SELECT run_id, CONCAT(run_id, '  [', status, ']') FROM pipeline_runs "
               "WHERE run_id <> 'UNKNOWN'")
    base = f"FROM delivery_events e WHERE {RUN_FILTER}"
    return [
        {"name": "run", "label": "Run", "type": "query", "datasource": DS,
         "query": run_sql, "definition": run_sql, "refresh": 2, "sort": 0,
         "multi": False, "includeAll": False,
         "current": {"selected": True, "text": "Latest run (auto)", "value": "latest"},
         "options": [], "hide": 0},
        multi("region", "Region", f"SELECT DISTINCT e.region {base} ORDER BY 1"),
        multi("city", "City", f"SELECT DISTINCT e.city {base} AND ('__ALL__' IN (${{region}}) "
                              f"OR e.region IN (${{region}})) ORDER BY 1"),
        multi("priority", "Priority", f"SELECT DISTINCT e.priority {base} ORDER BY 1"),
        multi("vehicle_type", "Vehicle type", f"SELECT DISTINCT e.vehicle_type {base} ORDER BY 1"),
        multi("order_day", "Order date", f"SELECT DISTINCT DATE_FORMAT(e.order_date, '%Y-%m-%d') "
                                         f"{base} ORDER BY 1"),
    ]


# ------------------------------------------------------------ panel kinds ---
def thresholds(*steps):
    """steps: (color, value) ... first value is None (base)."""
    return {"mode": "absolute", "steps": [{"color": c, "value": v} for c, v in steps]}


GREEN_BASE = thresholds(("green", None))
BLUE = thresholds(("blue", None))


def panel(kind, title, sql, purpose, interpretation, w, h, *, fmt="table", unit="none",
          decimals=None, thr=None, options=None, fieldcfg=None, overrides=None, viz=None,
          time_from=None, color_mode=None):
    p = {
        "type": kind, "title": title, "description": purpose, "datasource": DS,
        "targets": [{"refId": "A", "datasource": DS, "editorMode": "code", "format": fmt,
                     "rawQuery": True, "rawSql": q(sql)}] if sql else [],
        "fieldConfig": {"defaults": {"unit": unit, "thresholds": thr or BLUE,
                                     "color": {"mode": color_mode or "thresholds"}},
                        "overrides": overrides or []},
        "options": options or {},
        "_w": w, "_h": h, "_interp": interpretation, "_viz": viz or kind,
    }
    if decimals is not None:
        p["fieldConfig"]["defaults"]["decimals"] = decimals
    if fieldcfg:
        p["fieldConfig"]["defaults"].update(fieldcfg)
    if time_from:
        p["timeFrom"] = time_from
    return p


def stat(title, sql, purpose, interp, unit="none", thr=None, decimals=0, w=4, h=4):
    return panel("stat", title, sql, purpose, interp, w, h, unit=unit, thr=thr or BLUE,
                 decimals=decimals, viz="Stat",
                 options={"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": False},
                          "colorMode": "background", "graphMode": "none", "textMode": "value",
                          "justifyMode": "center", "orientation": "auto"})


def pie(title, sql, purpose, interp, w=8, h=9, donut=True):
    return panel("piechart", title, sql, purpose, interp, w, h, viz="Pie / donut chart",
                 color_mode="palette-classic",
                 options={"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": True},
                          "pieType": "donut" if donut else "pie",
                          "legend": {"displayMode": "table", "placement": "right",
                                     "values": ["value", "percent"], "showLegend": True},
                          "tooltip": {"mode": "single"}, "displayLabels": ["percent"]})


def bars(title, sql, purpose, interp, w=12, h=9, unit="none", stacked=False, horizontal=False,
         decimals=1, overrides=None):
    return panel("barchart", title, sql, purpose, interp, w, h, unit=unit, decimals=decimals,
                 viz="Bar chart" + (" (stacked)" if stacked else ""), color_mode="palette-classic",
                 overrides=overrides,
                 options={"orientation": "horizontal" if horizontal else "auto",
                          "stacking": "normal" if stacked else "none", "showValue": "auto",
                          "groupWidth": 0.7, "barWidth": 0.9, "xTickLabelRotation": 0,
                          "legend": {"displayMode": "list", "placement": "bottom", "showLegend": True},
                          "tooltip": {"mode": "multi"}},
                 fieldcfg={"custom": {"fillOpacity": 80, "lineWidth": 1, "gradientMode": "none"}})


def gauge_bars(title, sql, purpose, interp, w=12, h=9, unit="none", thr=None, decimals=1, maxv=None):
    fc = {"min": 0}
    if maxv is not None:
        fc["max"] = maxv
    return panel("bargauge", title, sql, purpose, interp, w, h, unit=unit, thr=thr, decimals=decimals,
                 viz="Bar gauge (one bar per row)", fieldcfg=fc,
                 options={"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": True},
                          "orientation": "horizontal", "displayMode": "gradient",
                          "showUnfilled": True, "valueMode": "color", "namePlacement": "left",
                          "sizing": "auto"})


def series(title, sql, purpose, interp, w=12, h=9, unit="none", stacked=False, bars_style=False):
    return panel("timeseries", title, sql, purpose, interp, w, h, fmt="time_series", unit=unit,
                 viz="Time series (ingestion time)", color_mode="palette-classic",
                 fieldcfg={"custom": {"drawStyle": "bars" if bars_style else "line",
                                      "lineWidth": 2, "fillOpacity": 25 if not bars_style else 70,
                                      "pointSize": 4, "showPoints": "auto", "spanNulls": False,
                                      "stacking": {"mode": "normal" if stacked else "none",
                                                   "group": "A"}}},
                 options={"legend": {"displayMode": "list", "placement": "bottom", "showLegend": True},
                          "tooltip": {"mode": "multi", "sort": "desc"}})


def table(title, sql, purpose, interp, w=24, h=10, overrides=None):
    return panel("table", title, sql, purpose, interp, w, h, viz="Table", overrides=overrides,
                 fieldcfg={"custom": {"align": "auto", "cellOptions": {"type": "auto"},
                                      "filterable": True}},
                 options={"showHeader": True, "cellHeight": "sm",
                          "footer": {"show": False, "reducer": ["sum"], "fields": ""}})


def color_col(name, unit, thr, decimals=1, mode="color-background"):
    """Override: colour one table column by thresholds."""
    return {"matcher": {"id": "byName", "options": name},
            "properties": [{"id": "unit", "value": unit}, {"id": "decimals", "value": decimals},
                           {"id": "thresholds", "value": thr},
                           {"id": "custom.cellOptions", "value": {"type": mode, "mode": "gradient"}}]}


def text(title, md, w=24, h=5):
    p = panel("text", title, None, "Notes", "", w, h, viz="Text")
    p["options"] = {"mode": "markdown", "content": md}
    return p


BREACH_THR = thresholds(("green", None), ("orange", 14), ("red", 18))
RISK_THR = thresholds(("green", None), ("orange", 50), ("red", 65))
DELAY_THR = thresholds(("green", None), ("orange", 10), ("red", 20))
ONTIME_THR = thresholds(("red", None), ("orange", 80), ("green", 88))
UTIL_THR = thresholds(("blue", None), ("green", 20), ("orange", 70), ("red", 90))

TIME_NOTE = ("**Timestamps.** KPI, breakdown and trend panels cover *all records of the selected run* and use the "
             "**event time from the CSV** (`order_date`, `order_time`, ETA, actual delivery). Panels marked "
             "*live* use **`ingested_at`** (when the processor wrote the row, UTC) and follow the time picker "
             "(default: last 15 minutes) so you can watch records arrive.")

# ============================================================ DASHBOARD 1 ===
D1 = {
    "uid": "logistics-ops-control-tower", "file": "01_delivery_operations_control_tower.json",
    "title": "1. Delivery Operations Control Tower",
    "problem": "How can operations managers monitor delivery workload, order status and current delivery performance?",
    "panels": [
        text("Problem statement",
             "### How can operations managers monitor delivery workload, order status and current delivery performance?\n"
             "Live control tower fed by **CSV → Kafka → Python processor → MySQL**. Use the filters above "
             "(run, region, city, priority, vehicle type, order date). Auto-refresh: **5 s**.\n\n" + TIME_NOTE,
             h=4),
        stat("Total orders", "SELECT COUNT(*) AS `Orders` FROM delivery_events e WHERE {F}",
             "Orders stored for the selected run and filters.",
             "Grows while the producer is streaming; 12,000 when the full CSV has been processed (no filters)."),
        stat("Processed events (run)",
             "SELECT r.inserted_count + r.rejected_count AS `Processed` FROM pipeline_runs r WHERE r.run_id = {RUN}",
             "Kafka events the processor has handled for this run (inserted + rejected). Not affected by filters.",
             "Should equal the source row count (12,000) at the end; compare with Total orders to spot rejects."),
        stat("Stream progress",
             "SELECT ROUND(100 * (r.inserted_count + r.rejected_count) / NULLIF(r.source_rows, 0), 1) AS `Progress` "
             "FROM pipeline_runs r WHERE r.run_id = {RUN}",
             "Share of the source CSV already processed for this run.",
             "Moves from 0 % to 100 % during the live demo.", unit="percent", decimals=1,
             thr=thresholds(("orange", None), ("green", 99.99))),
        stat("On-time delivery %",
             "SELECT ROUND(100 * SUM(e.order_status = 'Delivered' AND e.sla_breach = 0) / "
             "NULLIF(SUM(e.order_status = 'Delivered'), 0), 1) AS `On-time %` FROM delivery_events e WHERE {F}",
             "Delivered orders that met the SLA (sla_breach = No) / all delivered orders.",
             "Below 88 % turns amber, below 80 % red. The source SLA allows small delays (up to ~15 min) without a breach.",
             unit="percent", decimals=1, thr=ONTIME_THR),
        stat("Delivered (completed)",
             "SELECT SUM(e.order_status = 'Delivered') AS `Delivered` FROM delivery_events e WHERE {F}",
             "Orders with order_status = Delivered.", "Completed workload.",
             thr=thresholds(("green", None))),
        stat("Active (in transit / out for delivery)",
             f"SELECT SUM({OPEN}) AS `Active` FROM delivery_events e WHERE {{F}}",
             "Orders still moving: In Transit + Out for Delivery.", "Current open workload for the fleet.",
             thr=thresholds(("blue", None))),
        stat("Delayed (status)",
             "SELECT SUM(e.order_status = 'Delayed') AS `Delayed` FROM delivery_events e WHERE {F}",
             "Orders whose status is Delayed (not yet delivered).", "Exceptions that need intervention.",
             thr=thresholds(("orange", None))),
        stat("Cancelled",
             "SELECT SUM(e.order_status = 'Cancelled') AS `Cancelled` FROM delivery_events e WHERE {F}",
             "Orders with status Cancelled.", "Lost workload; watch for spikes in a city or hub.",
             thr=thresholds(("red", None))),
        stat("Avg delivery distance",
             "SELECT ROUND(AVG(e.delivery_distance_km), 1) AS `km` FROM delivery_events e WHERE {F}",
             "Mean delivery_distance_km.", "Longer average trips = heavier fleet load.",
             unit="lengthkm", decimals=1),
        stat("Orders needing re-attempt",
             "SELECT SUM(e.delivery_attempts > 1) AS `Re-attempts` FROM delivery_events e WHERE {F}",
             "Orders with delivery_attempts > 1.", "Each re-attempt is extra cost and a customer-experience risk.",
             thr=thresholds(("orange", None))),
        stat("Avg delay (all orders)",
             "SELECT ROUND(AVG(e.delay_minutes), 1) AS `min` FROM delivery_events e WHERE {F}",
             "Mean delay_minutes across all orders.", "Headline delay level; detail on dashboard 2.",
             unit="m", decimals=1, thr=DELAY_THR),
        stat("SLA breaches",
             "SELECT SUM(e.sla_breach = 1) AS `Breaches` FROM delivery_events e WHERE {F}",
             "Orders flagged sla_breach = Yes.", "Root causes on dashboard 2.",
             thr=thresholds(("red", None))),
        pie("Orders by delivery status",
            "SELECT e.order_status AS `Status`, COUNT(*) AS `Orders` FROM delivery_events e WHERE {F} "
            "GROUP BY e.order_status ORDER BY `Orders` DESC",
            "Status mix of the selected orders.",
            "In the full dataset ~62 % are Delivered, ~30 % still open (In Transit + Out for Delivery), ~6 % Delayed."),
        series("Live: events arriving per 10 s, by status",
               "SELECT $__timeGroupAlias(e.ingested_at, 10s), e.order_status AS metric, COUNT(*) AS value "
               "FROM delivery_events e WHERE $__timeFilter(e.ingested_at) AND {F} GROUP BY 1, 2 ORDER BY 1",
               "Live arrival rate of records written by the stream processor (ingestion time).",
               "Proves the pipeline is live: bars appear every refresh while producer.py runs and stop when it finishes.",
               w=16, stacked=True, bars_style=True),
        bars("Daily order volume by status (event date)",
             "SELECT DATE_FORMAT(e.order_date, '%d %b') AS `Day`, "
             "SUM(e.order_status = 'Delivered') AS `Delivered`, SUM(e.order_status = 'In Transit') AS `In Transit`, "
             "SUM(e.order_status = 'Out for Delivery') AS `Out for Delivery`, SUM(e.order_status = 'Delayed') AS `Delayed`, "
             "SUM(e.order_status = 'Cancelled') AS `Cancelled` FROM delivery_events e WHERE {F} "
             "GROUP BY e.order_date ORDER BY e.order_date",
             "Orders per order_date (event time from the CSV), split by status.",
             "With chronological streaming the bars fill from 1 Sep to 30 Sep as the demo runs.",
             w=16, stacked=True, decimals=0),
        bars("Order workload by hour of day",
             "SELECT LPAD(HOUR(e.order_time), 2, '0') AS `Hour`, COUNT(*) AS `Orders` FROM delivery_events e "
             "WHERE {F} GROUP BY `Hour` ORDER BY `Hour`",
             "Orders by order_time hour (07–20 h in the source).",
             "Peak hours are where dispatch capacity is most likely to bottleneck.", w=8, decimals=0),
        table("Bottleneck finder: hub workload and performance",
              f"SELECT e.hub AS `Hub`, COUNT(*) AS `Orders`, SUM({OPEN}) AS `Active`, "
              "SUM(e.order_status = 'Delayed') AS `Delayed status`, "
              f"ROUND(100 * SUM({OPEN} OR e.order_status = 'Delayed') / COUNT(*), 1) AS `Open backlog %`, "
              "ROUND(100 * AVG(e.sla_breach), 1) AS `SLA breach %`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, "
              "SUM(e.delivery_attempts > 1) AS `Re-attempts` FROM delivery_events e WHERE {F} "
              "GROUP BY e.hub ORDER BY `Open backlog %` DESC",
              "Workload, open backlog and service level per hub.",
              "Hubs at the top hold the largest share of unfinished orders; combine with SLA breach % to choose where to add riders.",
              w=12, h=9,
              overrides=[color_col("Open backlog %", "percent", thresholds(("green", None), ("orange", 36), ("red", 37))),
                         color_col("SLA breach %", "percent", BREACH_THR),
                         color_col("Avg delay (min)", "m", DELAY_THR)]),
        gauge_bars("Open backlog by city (active + delayed orders)",
                   f"SELECT e.city AS `City`, SUM({OPEN} OR e.order_status = 'Delayed') AS `Open orders` "
                   "FROM delivery_events e WHERE {F} GROUP BY e.city ORDER BY `Open orders` DESC",
                   "Orders not yet delivered or cancelled, per city.",
                   "Cities with the longest bars need the most dispatch attention right now.",
                   w=12, h=9, decimals=0, thr=thresholds(("blue", None), ("orange", 360), ("red", 375))),
        table("Latest orders streamed (newest first)",
              "SELECT DATE_FORMAT(e.ingested_at, '%H:%i:%s') AS `Ingested (UTC)`, e.order_id AS `Order`, "
              "DATE_FORMAT(e.order_ts, '%Y-%m-%d %H:%i') AS `Order time`, e.city AS `City`, e.hub AS `Hub`, "
              "e.priority AS `Priority`, e.order_status AS `Status`, e.vehicle_type AS `Vehicle`, "
              "e.delivery_distance_km AS `Distance (km)`, DATE_FORMAT(e.estimated_delivery_time, '%m-%d %H:%i') AS `ETA`, "
              "COALESCE(DATE_FORMAT(e.actual_delivery_time, '%m-%d %H:%i'), '-') AS `Delivered at`, "
              "e.delay_minutes AS `Delay (min)`, IF(e.sla_breach = 1, 'Yes', 'No') AS `SLA breach`, "
              "IF(e.at_risk = 1, 'Yes', 'No') AS `At risk` FROM delivery_events e WHERE {F} "
              "ORDER BY e.ingested_at DESC, e.source_row_number DESC LIMIT 50",
              "The 50 most recently ingested orders with key operational fields.",
              "Watch new orders appear at the top on every refresh during the demo.", h=11,
              overrides=[color_col("Delay (min)", "m", DELAY_THR, 0)]),
    ],
}

# ============================================================ DASHBOARD 2 ===
D2 = {
    "uid": "logistics-sla-delays", "file": "02_sla_compliance_and_delays.json",
    "title": "2. SLA Compliance and Delivery Delays",
    "problem": "Where and why are delivery commitments being missed?",
    "panels": [
        text("Problem statement",
             "### Where and why are delivery commitments being missed?\n"
             "`sla_breach` comes from the CSV as **Yes/No** and is stored as **1/0** (Python maps it, MySQL enforces "
             "0/1 with a CHECK constraint, SQL tests `sla_breach = 1`). `delay_reason = 'None'` is the source's label "
             "for *no delay*. " + TIME_NOTE, h=4),
        stat("SLA breaches", "SELECT SUM(e.sla_breach = 1) AS `Breaches` FROM delivery_events e WHERE {F}",
             "Orders with sla_breach = Yes.", "Absolute count of missed commitments.",
             thr=thresholds(("red", None))),
        stat("SLA breach rate", "SELECT ROUND(100 * AVG(e.sla_breach), 1) AS `Breach %` FROM delivery_events e WHERE {F}",
             "Breaches / all orders.", "About 13.6 % on the full dataset; amber from 14 %, red from 18 %.",
             unit="percent", decimals=1, thr=BREACH_THR),
        stat("Avg delay (all orders)", "SELECT ROUND(AVG(e.delay_minutes), 1) AS `Avg` FROM delivery_events e WHERE {F}",
             "Mean delay_minutes including on-time orders.", "Overall delay level.", unit="m", decimals=1, thr=DELAY_THR),
        stat("Avg delay when late", "SELECT ROUND(AVG(e.delay_minutes), 1) AS `Avg` FROM delivery_events e "
             "WHERE {F} AND e.delay_minutes > 0", "Mean delay of orders with delay_minutes > 0.",
             "How late the late orders are.", unit="m", decimals=1, thr=thresholds(("orange", None), ("red", 30))),
        stat("Max delay", "SELECT MAX(e.delay_minutes) AS `Max` FROM delivery_events e WHERE {F}",
             "Worst single delay.", "Outlier severity; see the worst-breaches table.", unit="m",
             thr=thresholds(("orange", None), ("red", 60))),
        stat("Orders with any delay", "SELECT ROUND(100 * AVG(e.delay_minutes > 0), 1) AS `%` FROM delivery_events e WHERE {F}",
             "Share of orders with delay_minutes > 0.", "Includes delays still inside the SLA grace window.",
             unit="percent", decimals=1, thr=thresholds(("green", None), ("orange", 35), ("red", 50))),
        bars("Daily SLA breach rate (event date)",
             "SELECT DATE_FORMAT(e.order_date, '%d %b') AS `Day`, ROUND(100 * AVG(e.sla_breach), 1) AS `Breach rate %` "
             "FROM delivery_events e WHERE {F} GROUP BY e.order_date ORDER BY e.order_date",
             "Breach rate per order_date.", "Spikes point to specific days (weather, events) worth investigating.",
             w=12, unit="percent"),
        bars("Daily average and maximum delay (event date)",
             "SELECT DATE_FORMAT(e.order_date, '%d %b') AS `Day`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, "
             "MAX(e.delay_minutes) AS `Max delay (min)` FROM delivery_events e WHERE {F} "
             "GROUP BY e.order_date ORDER BY e.order_date",
             "Delay trend over the order dates.", "A rising average signals systemic problems; isolated max spikes are outliers.",
             w=12, unit="m"),
        series("Live: SLA breach rate of arriving orders (per 30 s)",
               "SELECT $__timeGroupAlias(e.ingested_at, 30s), ROUND(100 * AVG(e.sla_breach), 1) AS `Breach rate %` "
               "FROM delivery_events e WHERE $__timeFilter(e.ingested_at) AND {F} GROUP BY 1 ORDER BY 1",
               "Breach rate of the records ingested in each 30-second window.",
               "Lets you watch compliance of the incoming stream in real time.", w=24, h=7, unit="percent"),
        gauge_bars("SLA breach rate by city",
                   "SELECT e.city AS `City`, ROUND(100 * AVG(e.sla_breach), 1) AS `Breach %` FROM delivery_events e "
                   "WHERE {F} GROUP BY e.city ORDER BY `Breach %` DESC",
                   "Breach rate per city, worst first.", "Pune and Noida (~15 %) lead; Gurugram is best (~12 %). Spread is narrow, so causes are mostly traffic/road related rather than city-specific.",
                   w=12, h=10, unit="percent", thr=thresholds(("green", None), ("orange", 14), ("red", 15)), maxv=20),
        table("SLA performance by region",
              "SELECT e.region AS `Region`, COUNT(*) AS `Orders`, SUM(e.sla_breach) AS `Breaches`, "
              "ROUND(100 * AVG(e.sla_breach), 1) AS `Breach %`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, "
              "MAX(e.delay_minutes) AS `Max delay (min)`, ROUND(100 * AVG(e.at_risk), 1) AS `At-risk %` "
              "FROM delivery_events e WHERE {F} GROUP BY e.region ORDER BY `Breach %` DESC",
              "Regional SLA comparison.", "Compare breach rate against volume to prioritise regional action.",
              w=12, h=10, overrides=[color_col("Breach %", "percent", BREACH_THR),
                                     color_col("Avg delay (min)", "m", DELAY_THR)]),
        pie("Delay reasons (delayed orders only)",
            "SELECT e.delay_reason AS `Reason`, COUNT(*) AS `Orders` FROM delivery_events e WHERE {F} "
            "AND e.delay_reason <> 'None' GROUP BY e.delay_reason ORDER BY `Orders` DESC",
            "Why orders were delayed (delay_reason, excluding 'None').",
            "Traffic dominates delay volume in this dataset.", w=10, h=10),
        bars("Breached vs within SLA by delay reason",
             "SELECT e.delay_reason AS `Reason`, SUM(e.sla_breach = 1) AS `Breached`, SUM(e.sla_breach = 0) AS `Within SLA` "
             "FROM delivery_events e WHERE {F} AND e.delay_reason <> 'None' GROUP BY e.delay_reason ORDER BY `Breached` DESC",
             "For each reason, how many delays turned into SLA breaches.",
             "Traffic causes the most breaches by volume, but Vehicle Issue, Weather and Address Issue break the SLA ~2 times in 3.",
             w=14, h=10, stacked=True, decimals=0),
        bars("Traffic level impact",
             "SELECT e.traffic_level AS `Traffic`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, "
             "ROUND(100 * AVG(e.sla_breach), 1) AS `Breach rate %` FROM delivery_events e WHERE {F} "
             f"GROUP BY e.traffic_level ORDER BY {TRAFFIC_ORDER}",
             "Average delay and breach rate by traffic_level.", "High/Severe traffic raises average delay from ~3 min to ~23-24 min and breach rate from ~4 % to 33-38 %: the single biggest driver.",
             w=12),
        bars("Route condition impact",
             "SELECT e.route_condition AS `Route condition`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, "
             "ROUND(100 * AVG(e.sla_breach), 1) AS `Breach rate %` FROM delivery_events e WHERE {F} "
             f"GROUP BY e.route_condition ORDER BY {ROUTE_ORDER}",
             "Average delay and breach rate by route_condition.", "Poor roads nearly triple average delay (~23 min vs ~8) and breach rate (~31 % vs ~11 %): re-routing candidates.",
             w=12),
        table("SLA comparison by priority",
              "SELECT e.priority AS `Priority`, COUNT(*) AS `Orders`, SUM(e.sla_breach) AS `Breaches`, "
              "ROUND(100 * AVG(e.sla_breach), 1) AS `Breach %`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, "
              "MAX(e.delay_minutes) AS `Max delay (min)` FROM delivery_events e WHERE {F} "
              f"GROUP BY e.priority ORDER BY {PRIORITY_ORDER}",
              "SLA outcome per service level.", "Express (~26 %) and Priority (~22 %) orders breach far more often than Standard (~10 %): the premium promise is the weakest link.",
              w=12, h=8, overrides=[color_col("Breach %", "percent", BREACH_THR)]),
        bars("Delay distribution",
             "SELECT b.band AS `Delay band`, COUNT(*) AS `Orders` FROM (SELECT CASE "
             "WHEN e.delay_minutes = 0 THEN '0 on time' WHEN e.delay_minutes <= 15 THEN '1-15 min' "
             "WHEN e.delay_minutes <= 30 THEN '16-30 min' WHEN e.delay_minutes <= 60 THEN '31-60 min' "
             "ELSE '60+ min' END AS band FROM delivery_events e WHERE {F}) b GROUP BY b.band ORDER BY b.band",
             "Orders per delay band.", "Most orders are on time; the 31+ min tail drives almost all breaches.",
             w=12, h=8, decimals=0),
        table("Worst SLA breaches (top 25)",
              "SELECT e.order_id AS `Order`, e.city AS `City`, e.hub AS `Hub`, e.priority AS `Priority`, "
              "e.order_status AS `Status`, e.vehicle_type AS `Vehicle`, e.traffic_level AS `Traffic`, "
              "e.route_condition AS `Route`, e.delay_reason AS `Reason`, e.delay_minutes AS `Delay (min)`, "
              "DATE_FORMAT(e.estimated_delivery_time, '%Y-%m-%d %H:%i') AS `ETA` FROM delivery_events e "
              "WHERE {F} AND e.sla_breach = 1 ORDER BY e.delay_minutes DESC, e.order_id LIMIT 25",
              "Largest breaches with their context.", "Use for root-cause review of individual failures.",
              h=10, overrides=[color_col("Delay (min)", "m", thresholds(("orange", None), ("red", 60)), 0)]),
    ],
}

# ============================================================ DASHBOARD 3 ===
D3 = {
    "uid": "logistics-fleet-efficiency", "file": "03_fleet_and_resource_efficiency.json",
    "title": "3. Fleet and Resource Efficiency",
    "problem": "How efficiently are vehicles and delivery resources being utilized?",
    "panels": [
        text("Problem statement and data limits",
             "### How efficiently are vehicles and delivery resources being utilized?\n"
             "**Available in the CSV:** vehicle_type, vehicle_capacity_kg, vehicle_status, package_weight_kg, "
             "fuel_level_pct, speed_kmph, delivery_distance_km, driver_id, driver_experience_years.  "
             "**Not available (not invented):** fuel *consumption* (litres/km), cost, engine hours, driver ratings. "
             "Fuel panels therefore show the **fuel level snapshot**, not consumption. "
             "**Derived:** `load_utilization_pct = package_weight_kg / vehicle_capacity_kg × 100` (one package per order). "
             "Vehicle fields are **per-order snapshots**: the same vehicle_id can appear with different types/statuses "
             "in the source, so vehicles are analysed by type, not as a fixed fleet register.", h=5),
        stat("Vehicles used", "SELECT COUNT(DISTINCT e.vehicle_id) AS `Vehicles` FROM delivery_events e WHERE {F}",
             "Distinct vehicle_id values.", "Fleet size engaged for the filtered orders."),
        stat("Drivers used", "SELECT COUNT(DISTINCT e.driver_id) AS `Drivers` FROM delivery_events e WHERE {F}",
             "Distinct driver_id values.", "Workforce engaged."),
        stat("Avg speed", "SELECT ROUND(AVG(e.speed_kmph), 1) AS `km/h` FROM delivery_events e WHERE {F}",
             "Mean speed_kmph.", "Lower speed in a city = congestion or poor routes.", unit="velocitykmh", decimals=1),
        stat("Avg fuel level", "SELECT ROUND(AVG(e.fuel_level_pct), 1) AS `%` FROM delivery_events e WHERE {F}",
             "Mean fuel_level_pct snapshot (not consumption).", "Proxy for refuelling pressure.",
             unit="percent", decimals=1, thr=thresholds(("red", None), ("orange", 25), ("green", 40))),
        stat("Low-fuel orders (<20 %)", "SELECT SUM(e.fuel_level_pct < 20) AS `Orders` FROM delivery_events e WHERE {F}",
             "Orders served by a vehicle below 20 % fuel.", "Breakdown / detour risk; schedule refuelling.",
             thr=thresholds(("orange", None))),
        stat("Avg load utilization", "SELECT ROUND(AVG(e.load_utilization_pct), 1) AS `%` FROM delivery_events e WHERE {F}",
             "DERIVED: mean package weight / vehicle capacity.", "Very low values mean oversized vehicles for the parcel.",
             unit="percent", decimals=1, thr=UTIL_THR),
        table("Vehicle-type comparison",
              "SELECT e.vehicle_type AS `Vehicle type`, MAX(e.vehicle_capacity_kg) AS `Capacity (kg)`, COUNT(*) AS `Orders`, "
              "ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS `Share of orders %`, "
              "ROUND(AVG(e.delivery_distance_km), 1) AS `Avg distance (km)`, ROUND(AVG(e.speed_kmph), 1) AS `Avg speed (km/h)`, "
              "ROUND(AVG(e.package_weight_kg), 2) AS `Avg package (kg)`, MAX(e.package_weight_kg) AS `Max package (kg)`, "
              "ROUND(AVG(e.load_utilization_pct), 1) AS `Avg load util %`, ROUND(AVG(e.fuel_level_pct), 1) AS `Avg fuel %`, "
              "ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, ROUND(100 * AVG(e.sla_breach), 1) AS `SLA breach %` "
              f"FROM delivery_events e WHERE {{F}} GROUP BY e.vehicle_type ORDER BY {VEHICLE_ORDER}",
              "Side-by-side efficiency profile of each vehicle type.",
              "Bikes use ~43 % of their 20 kg limit on average, vans ~9 %, mini trucks ~3 %, trucks under 1 %: heavy vehicles are badly under-loaded (right-sizing opportunity). Delay and breach rates are almost identical across types.",
              h=7, overrides=[color_col("Avg load util %", "percent", UTIL_THR),
                              color_col("SLA breach %", "percent", BREACH_THR),
                              color_col("Avg delay (min)", "m", DELAY_THR)]),
        bars("Delay and SLA breach by vehicle type",
             "SELECT e.vehicle_type AS `Vehicle type`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, "
             "ROUND(100 * AVG(e.sla_breach), 1) AS `SLA breach %` FROM delivery_events e WHERE {F} "
             f"GROUP BY e.vehicle_type ORDER BY {VEHICLE_ORDER}",
             "Service performance per vehicle type.", "All four types sit at ~9.6-9.8 min average delay and 13-14 % breach rate: vehicle type is not what drives SLA misses.",
             w=12),
        pie("Vehicle status at order time",
            "SELECT e.vehicle_status AS `Vehicle status`, COUNT(*) AS `Orders` FROM delivery_events e WHERE {F} "
            "GROUP BY e.vehicle_status ORDER BY `Orders` DESC",
            "vehicle_status snapshot recorded with each order.",
            "A high Maintenance share signals fleet availability risk.", w=12),
        bars("Fuel level bands by vehicle type",
             "SELECT e.vehicle_type AS `Vehicle type`, SUM(e.fuel_level_pct < 20) AS `Low (<20%)`, "
             "SUM(e.fuel_level_pct >= 20 AND e.fuel_level_pct < 50) AS `Medium (20-50%)`, "
             "SUM(e.fuel_level_pct >= 50) AS `High (50%+)` FROM delivery_events e WHERE {F} "
             f"GROUP BY e.vehicle_type ORDER BY {VEHICLE_ORDER}",
             "Distribution of fuel_level_pct snapshots per vehicle type (fuel level, NOT consumption).",
             "Large 'Low' bars point to refuelling planning gaps.", w=12, stacked=True, decimals=0),
        bars("Driver experience vs performance",
             "SELECT b.band AS `Experience`, COUNT(*) AS `Orders`, ROUND(AVG(b.delay_minutes), 1) AS `Avg delay (min)`, "
             "ROUND(100 * AVG(b.sla_breach), 1) AS `SLA breach %`, ROUND(AVG(b.speed_kmph), 1) AS `Avg speed (km/h)` FROM "
             "(SELECT CASE WHEN e.driver_experience_years < 2 THEN '0-2 yrs' WHEN e.driver_experience_years < 5 THEN '2-5 yrs' "
             "WHEN e.driver_experience_years < 8 THEN '5-8 yrs' ELSE '8-12 yrs' END AS band, e.delay_minutes, e.sla_breach, "
             "e.speed_kmph FROM delivery_events e WHERE {F}) b GROUP BY b.band ORDER BY b.band",
             "Delay, breach rate and speed by driver_experience_years band (orders shown in tooltip/legend).",
             "In this dataset delay (~9.4-9.9 min) and breach rate (~13-14 %) are nearly flat across experience bands, so experience is not the main driver of lateness; traffic and road condition are (see dashboard 2).",
             w=12, overrides=[{"matcher": {"id": "byName", "options": "Orders"},
                               "properties": [{"id": "custom.hideFrom",
                                               "value": {"viz": True, "legend": False, "tooltip": False}}]}]),
        bars("Load utilization by vehicle type (derived)",
             "SELECT e.vehicle_type AS `Vehicle type`, ROUND(AVG(e.load_utilization_pct), 2) AS `Avg utilization %`, "
             "ROUND(MAX(e.load_utilization_pct), 2) AS `Max utilization %` FROM delivery_events e WHERE {F} "
             f"GROUP BY e.vehicle_type ORDER BY {VEHICLE_ORDER}",
             "Package weight as % of vehicle capacity.",
             "Bikes average ~43 % (max 85 %) of their 20 kg limit; vans ~9 %, mini trucks ~3 %, trucks under 1 % of 2,500 kg. Heavy vehicles are under-loaded.",
             w=12, unit="percent", decimals=1),
        bars("Package weight vs vehicle capacity",
             "SELECT e.vehicle_type AS `Vehicle type`, MAX(e.vehicle_capacity_kg) AS `Capacity (kg)`, "
             "ROUND(AVG(e.package_weight_kg), 1) AS `Avg package (kg)`, MAX(e.package_weight_kg) AS `Max package (kg)` "
             f"FROM delivery_events e WHERE {{F}} GROUP BY e.vehicle_type ORDER BY {VEHICLE_ORDER}",
             "Capacity against actual package weights (log scale).", "Gap between bars = unused capacity.",
             w=12, unit="masskg"),
        bars("Average speed by traffic level and vehicle type",
             "SELECT e.traffic_level AS `Traffic`, "
             "ROUND(AVG(CASE WHEN e.vehicle_type = 'Bike' THEN e.speed_kmph END), 1) AS `Bike`, "
             "ROUND(AVG(CASE WHEN e.vehicle_type = 'Van' THEN e.speed_kmph END), 1) AS `Van`, "
             "ROUND(AVG(CASE WHEN e.vehicle_type = 'Mini Truck' THEN e.speed_kmph END), 1) AS `Mini Truck`, "
             "ROUND(AVG(CASE WHEN e.vehicle_type = 'Truck' THEN e.speed_kmph END), 1) AS `Truck` "
             f"FROM delivery_events e WHERE {{F}} GROUP BY e.traffic_level ORDER BY {TRAFFIC_ORDER}",
             "Mean speed_kmph per traffic level for each vehicle type.",
             "Which vehicle class keeps moving in heavy traffic (useful for congested-city allocation).",
             w=12, unit="velocitykmh"),
        bars("Distance band vs delay and speed",
             "SELECT b.band AS `Distance`, ROUND(AVG(b.delay_minutes), 1) AS `Avg delay (min)`, "
             "ROUND(AVG(b.speed_kmph), 1) AS `Avg speed (km/h)` FROM (SELECT CASE "
             "WHEN e.delivery_distance_km < 15 THEN '1) <15 km' WHEN e.delivery_distance_km < 30 THEN '2) 15-30 km' "
             "WHEN e.delivery_distance_km < 45 THEN '3) 30-45 km' ELSE '4) 45+ km' END AS band, e.delay_minutes, "
             "e.speed_kmph FROM delivery_events e WHERE {F}) b GROUP BY b.band ORDER BY b.band",
             "Effect of trip length on delay and speed.", "Shows whether long trips need different vehicle allocation.",
             w=12),
        table("Busiest drivers (top 15 by orders)",
              "SELECT e.driver_id AS `Driver`, COUNT(*) AS `Orders`, ROUND(SUM(e.delivery_distance_km), 1) AS `Total km`, "
              "ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, ROUND(100 * AVG(e.sla_breach), 1) AS `SLA breach %`, "
              "ROUND(AVG(e.driver_experience_years), 1) AS `Avg experience (yrs)`, COUNT(DISTINCT e.vehicle_type) AS `Vehicle types` "
              "FROM delivery_events e WHERE {F} GROUP BY e.driver_id ORDER BY `Orders` DESC, `Driver` LIMIT 15",
              "Driver workload and outcomes.", "Balance load away from overworked drivers with high breach %.",
              h=9, overrides=[color_col("SLA breach %", "percent", BREACH_THR),
                              color_col("Avg delay (min)", "m", DELAY_THR)]),
    ],
}
# log scale for capacity panel
for _p in D3["panels"]:
    if _p["title"] == "Package weight vs vehicle capacity":
        _p["fieldConfig"]["defaults"]["custom"]["scaleDistribution"] = {"type": "log", "log": 10}

# ============================================================ DASHBOARD 4 ===
D4 = {
    "uid": "logistics-risk-route", "file": "04_last_mile_risk_and_route_intelligence.json",
    "title": "4. Last-Mile Risk and Route Intelligence",
    "problem": "Which orders, routes and locations are most at risk of late delivery?",
    "panels": [
        text("Problem statement",
             "### Which orders, routes and locations are most at risk of late delivery?\n"
             "`at_risk` is a **source-provided** Yes/No flag (stored 1/0). In the data it is set only for **open** orders "
             "(In Transit, Out for Delivery), so risk rates use open orders as the base. `eta_variance_minutes` is "
             "source-provided (for delivered orders it equals the delay; for open orders it is the projected variance, "
             "negative = ahead of ETA). The CSV has **no route/road-segment ID**, so *lanes* are **derived** as "
             "`hub → city`. Map tiles load from the internet in your browser.", h=4),
        stat("Open orders", f"SELECT SUM({OPEN}) AS `Open` FROM delivery_events e WHERE {{F}}",
             "In Transit + Out for Delivery.", "Base for risk rates."),
        stat("At-risk orders", "SELECT SUM(e.at_risk = 1) AS `At risk` FROM delivery_events e WHERE {F}",
             "Orders with source flag at_risk = Yes.", "Orders likely to be late if nothing changes.",
             thr=thresholds(("red", None))),
        stat("At-risk share of open orders",
             f"SELECT ROUND(100 * SUM(e.at_risk = 1) / NULLIF(SUM({OPEN}), 0), 1) AS `%` FROM delivery_events e WHERE {{F}}",
             "At-risk / open orders.", "About 63 % on the full data; amber above 50 %, red above 65 %.",
             unit="percent", decimals=1, thr=RISK_THR),
        stat("Avg ETA variance (open)",
             f"SELECT ROUND(AVG(e.eta_variance_minutes), 1) AS `min` FROM delivery_events e WHERE {{F}} AND {OPEN}",
             "Mean projected ETA variance of open orders.", "Positive = running behind ETA.",
             unit="m", decimals=1, thr=DELAY_THR),
        stat("Max ETA variance (open)",
             f"SELECT MAX(e.eta_variance_minutes) AS `min` FROM delivery_events e WHERE {{F}} AND {OPEN}",
             "Worst projected variance.", "Top of the watch-list below.", unit="m",
             thr=thresholds(("orange", None), ("red", 30))),
        stat("At-risk Express + Priority",
             "SELECT SUM(e.at_risk = 1 AND e.priority IN ('Express', 'Priority')) AS `Orders` FROM delivery_events e WHERE {F}",
             "At-risk orders on premium service levels.", "Highest-value interventions: escalate these first.",
             thr=thresholds(("orange", None))),
        panel("geomap", "Map: at-risk open orders (colour = ETA variance)",
              "SELECT e.latitude AS `latitude`, e.longitude AS `longitude`, e.order_id AS `Order`, e.city AS `City`, "
              "e.priority AS `Priority`, e.traffic_level AS `Traffic`, e.eta_variance_minutes AS `ETA variance (min)` "
              "FROM delivery_events e WHERE {F} AND e.at_risk = 1",
              "Location (source latitude/longitude) of each at-risk order.",
              "Clusters show where to send support riders; red dots are the furthest behind ETA.",
              14, 13, unit="m", viz="Geomap (markers)",
              thr=thresholds(("green", None), ("orange", 15), ("red", 30)),
              options={"view": {"id": "coords", "lat": 22.5, "lon": 79.5, "zoom": 4.3, "allLayers": True},
                       "controls": {"showZoom": True, "mouseWheelZoom": True, "showAttribution": True},
                       "basemap": {"type": "default", "name": "Basemap", "config": {}},
                       "layers": [{"type": "markers", "name": "At-risk orders", "tooltip": True,
                                   "location": {"mode": "coords", "latitude": "latitude", "longitude": "longitude"},
                                   "config": {"showLegend": True,
                                              "style": {"size": {"fixed": 4},
                                                        "color": {"field": "ETA variance (min)", "fixed": "red"},
                                                        "opacity": 0.6,
                                                        "symbol": {"fixed": "img/icons/marker/circle.svg", "mode": "fixed"}}}}],
                       "tooltip": {"mode": "details"}}),
        gauge_bars("At-risk share of open orders by city",
                   f"SELECT e.city AS `City`, ROUND(100 * SUM(e.at_risk = 1) / NULLIF(SUM({OPEN}), 0), 1) AS `At-risk %` "
                   "FROM delivery_events e WHERE {F} GROUP BY e.city ORDER BY `At-risk %` DESC",
                   "Risk rate per city.", "Cities at the top need proactive customer communication and re-routing.",
                   w=10, h=13, unit="percent", thr=RISK_THR, maxv=100),
        table("Risk by region",
              f"SELECT e.region AS `Region`, SUM({OPEN}) AS `Open`, SUM(e.at_risk = 1) AS `At risk`, "
              f"ROUND(100 * SUM(e.at_risk = 1) / NULLIF(SUM({OPEN}), 0), 1) AS `At-risk %`, "
              f"ROUND(AVG(CASE WHEN {OPEN} THEN e.eta_variance_minutes END), 1) AS `Avg ETA var (open, min)` "
              "FROM delivery_events e WHERE {F} GROUP BY e.region ORDER BY `At-risk %` DESC",
              "Regional risk comparison.", "Regional managers can compare exposure on one line each.",
              w=8, h=8, overrides=[color_col("At-risk %", "percent", RISK_THR)]),
        bars("Priority-wise risk",
             f"SELECT e.priority AS `Priority`, SUM({OPEN}) AS `Open`, SUM(e.at_risk = 1) AS `At risk` "
             f"FROM delivery_events e WHERE {{F}} GROUP BY e.priority ORDER BY {PRIORITY_ORDER}",
             "Open vs at-risk orders per priority.", "A large at-risk bar on Express threatens the premium promise.",
             w=8, h=8, decimals=0),
        table("Risk matrix: traffic level x route condition (at-risk % of open)",
              "SELECT e.traffic_level AS `Traffic`, "
              f"ROUND(100 * SUM(e.at_risk = 1 AND e.route_condition = 'Good') / NULLIF(SUM({OPEN} AND e.route_condition = 'Good'), 0), 1) AS `Good road`, "
              f"ROUND(100 * SUM(e.at_risk = 1 AND e.route_condition = 'Moderate') / NULLIF(SUM({OPEN} AND e.route_condition = 'Moderate'), 0), 1) AS `Moderate road`, "
              f"ROUND(100 * SUM(e.at_risk = 1 AND e.route_condition = 'Poor') / NULLIF(SUM({OPEN} AND e.route_condition = 'Poor'), 0), 1) AS `Poor road` "
              f"FROM delivery_events e WHERE {{F}} GROUP BY e.traffic_level ORDER BY {TRAFFIC_ORDER}",
              "At-risk share for each combination of traffic_level and route_condition.",
              "The bottom-right cells (severe traffic, poor roads) are the riskiest route conditions.",
              w=8, h=8, overrides=[color_col(c, "percent", RISK_THR) for c in ("Good road", "Moderate road", "Poor road")]),
        bars("ETA variance distribution (open orders)",
             "SELECT b.band AS `ETA variance`, COUNT(*) AS `Open orders`, SUM(b.at_risk) AS `Of which at risk` FROM "
             "(SELECT CASE WHEN e.eta_variance_minutes < 0 THEN '1) ahead (<0)' WHEN e.eta_variance_minutes = 0 THEN '2) on ETA' "
             "WHEN e.eta_variance_minutes <= 15 THEN '3) 1-15 min' WHEN e.eta_variance_minutes <= 30 THEN '4) 16-30 min' "
             f"ELSE '5) 30+ min' END AS band, e.at_risk FROM delivery_events e WHERE {{F}} AND {OPEN}) b "
             "GROUP BY b.band ORDER BY b.band",
             "How far behind ETA the open orders are, and how many are flagged.",
             "Shows how the source at_risk flag lines up with projected lateness.", w=12, decimals=0),
        series("Live: at-risk orders arriving (per 30 s)",
               f"SELECT $__timeGroupAlias(e.ingested_at, 30s), SUM({OPEN}) AS `Open orders`, "
               "SUM(e.at_risk = 1) AS `At-risk orders` FROM delivery_events e "
               "WHERE $__timeFilter(e.ingested_at) AND {F} GROUP BY 1 ORDER BY 1",
               "Open and at-risk orders among records ingested in each 30-second window.",
               "Live view of the risk flowing into the control room.", w=12, bars_style=True),
        table("Lane comparison: hub → city (derived lanes, top 20 by at-risk orders)",
              f"SELECT CONCAT(e.hub, ' → ', e.city) AS `Lane (derived)`, SUM({OPEN}) AS `Open`, SUM(e.at_risk = 1) AS `At risk`, "
              f"ROUND(100 * SUM(e.at_risk = 1) / NULLIF(SUM({OPEN}), 0), 1) AS `At-risk %`, "
              f"ROUND(AVG(CASE WHEN {OPEN} THEN e.eta_variance_minutes END), 1) AS `Avg ETA var (min)`, "
              "ROUND(AVG(e.delivery_distance_km), 1) AS `Avg distance (km)`, ROUND(100 * AVG(e.traffic_level IN ('High', 'Severe')), 1) AS `Heavy traffic %` "
              "FROM delivery_events e WHERE {F} GROUP BY e.hub, e.city ORDER BY `At risk` DESC, `Lane (derived)` LIMIT 20",
              "Risk per hub-to-city lane (derived, the CSV has no route ID).",
              "Lanes with high at-risk count AND high heavy-traffic share are re-routing candidates.",
              w=12, h=10, overrides=[color_col("At-risk %", "percent", RISK_THR)]),
        table("At-risk watch-list (top 50 by ETA variance)",
              "SELECT e.order_id AS `Order`, e.city AS `City`, e.hub AS `Hub`, e.priority AS `Priority`, "
              "e.order_status AS `Status`, e.vehicle_type AS `Vehicle`, e.traffic_level AS `Traffic`, "
              "e.route_condition AS `Route`, e.delivery_distance_km AS `Distance (km)`, "
              "DATE_FORMAT(e.estimated_delivery_time, '%Y-%m-%d %H:%i') AS `ETA`, e.eta_variance_minutes AS `ETA variance (min)` "
              "FROM delivery_events e WHERE {F} AND e.at_risk = 1 "
              "ORDER BY e.eta_variance_minutes DESC, FIELD(e.priority, 'Express', 'Priority', 'Standard'), e.order_id LIMIT 50",
              "At-risk orders sorted by how far behind ETA they are.", "Call-list for the dispatch team.",
              w=12, h=10, overrides=[color_col("ETA variance (min)", "m", thresholds(("green", None), ("orange", 15), ("red", 30)), 0)]),
    ],
}

DASHBOARDS = [D1, D2, D3, D4]


# --------------------------------------------------------------- assemble ---
def layout(panels):
    x = y = row_h = 0
    out = []
    for i, p in enumerate(panels, start=1):
        w, h = p["_w"], p["_h"]
        if x + w > 24:
            x, y, row_h = 0, y + row_h, 0
        clean = {k: v for k, v in p.items() if not k.startswith("_")}
        clean["id"] = i
        clean["gridPos"] = {"x": x, "y": y, "w": w, "h": h}
        out.append(clean)
        x += w
        row_h = max(row_h, h)
    return out


def links():
    return [{"title": d["title"], "url": f"/d/{d['uid']}", "type": "link", "icon": "dashboard",
             "keepTime": True, "includeVars": True, "targetBlank": False} for d in DASHBOARDS]


def build(d):
    return {
        "uid": d["uid"], "title": d["title"], "description": d["problem"],
        "tags": ["logistics", "streaming", "kafka", "mysql"],
        "timezone": "browser", "editable": True, "graphTooltip": 1,
        "refresh": "5s", "time": {"from": "now-15m", "to": "now"},
        "timepicker": {"refresh_intervals": ["5s", "10s", "30s", "1m", "5m"]},
        "schemaVersion": 39, "version": 1, "liveNow": False,
        "templating": {"list": variables()}, "annotations": {"list": []},
        "links": links(), "panels": layout(d["panels"]),
    }


def main():
    out_dir = ROOT / "grafana" / "dashboards"
    sql_lines = ["-- ===========================================================================",
                 "-- grafana_queries.sql  (GENERATED by tools/build_dashboards.py)",
                 "-- Exact SQL of every panel in the four dashboards (MySQL 8.4).",
                 "-- ${...} are Grafana dashboard variables; $__timeFilter / $__timeGroupAlias",
                 "-- are Grafana MySQL macros. To run a query by hand in MySQL, replace:",
                 "--   ${run}           -> 'latest'",
                 "--   ${region} etc.   -> '__ALL__'   (or a list like 'North','West')",
                 "--   $__timeFilter(e.ingested_at) -> e.ingested_at > NOW() - INTERVAL 1 DAY",
                 "--   $__timeGroupAlias(e.ingested_at, 10s) -> FROM_UNIXTIME(FLOOR(UNIX_TIMESTAMP(e.ingested_at)/10)*10) AS time",
                 "-- ===========================================================================", ""]
    sql_lines.append("-- ---------- dashboard variables (same on all four dashboards) ----------")
    for v in variables():
        sql_lines += [f"-- variable ${v['name']} ({v['label']})", v["query"] + ";", ""]
    doc = ["# Dashboard guide", "",
           "_Generated from `tools/build_dashboards.py` together with the dashboard JSON, so the SQL below is exactly "
           "what each panel runs._", "",
           "## Common to all four dashboards", "",
           "* **URL:** http://localhost:3000 → *Dashboards* → folder **Logistics Streaming Analytics**. "
           "Links to the other three dashboards are in the top-right of every dashboard.",
           "* **Auto-refresh:** 5 s (change in the refresh picker; minimum allowed is 5 s).",
           "* **Time picker:** default *Last 15 minutes*. It only affects panels titled **Live:** (they use "
           "`ingested_at`, the time the processor wrote the row, in UTC, displayed in your browser time zone). "
           "All other panels show **every record of the selected run** and use the **CSV event time** "
           "(`order_date` / `order_time`, Sep 2026, shown as written in the CSV).",
           "* **Filters (dropdowns):** Run, Region, City (cascades from Region), Priority, Vehicle type, Order date. "
           "Each multi-select has an **All** option. How *All* is configured: *Include All option* = on, "
           "*Custom all value* = `'__ALL__'` (with the quotes), and every query uses "
           "`('__ALL__' IN (${city}) OR e.city IN (${city}))`. This keeps queries valid even before any data has "
           "arrived (an empty `IN ()` would be a SQL error).",
           "* **Run filter:** *Latest run (auto)* always follows the newest run in `pipeline_runs`; older runs can be "
           "picked explicitly. After `reset_database.py` only the new run exists.",
           "* **Yes/No fields:** `sla_breach`, `at_risk` are `Yes/No` in the CSV, 1/0 in MySQL, and shown as Yes/No "
           "again in tables via `IF(x = 1, 'Yes', 'No')`.", ""]
    for d in DASHBOARDS:
        dash = build(d)
        (out_dir / d["file"]).write_text(json.dumps(dash, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        sql_lines += ["", "-- " + "=" * 75, f"-- {d['title']}", f"-- Problem: {d['problem']}", "-- " + "=" * 75]
        doc += [f"## {d['title']}", "", f"**Problem statement:** {d['problem']}", "",
                f"**URL:** http://localhost:3000/d/{d['uid']}  ·  **File:** `grafana/dashboards/{d['file']}`", ""]
        for p in d["panels"]:
            if p["type"] == "text":
                continue
            sql = p["targets"][0]["rawSql"]
            unit = p["fieldConfig"]["defaults"].get("unit", "none")
            steps = p["fieldConfig"]["defaults"]["thresholds"]["steps"]
            thr = ", ".join(f"{s['color']}" + (f" ≥ {s['value']}" if s["value"] is not None else " (base)") for s in steps)
            sql_lines += ["", f"-- [{p['_viz']}] {p['title']}", f"-- Purpose: {p['description']}", sql + ";"]
            doc += [f"### {p['title']}", "",
                    f"* **Purpose:** {p['description']}",
                    f"* **Visualization:** {p['_viz']}  ·  **Unit:** `{unit}`  ·  **Thresholds:** {thr}  ·  "
                    "**Legend:** auto (series = column names)",
                    f"* **Interpretation:** {p['_interp']}", "", "```sql", sql, "```", ""]
    (ROOT / "grafana_queries.sql").write_text("\n".join(sql_lines) + "\n", encoding="utf-8")
    (ROOT / "docs" / "DASHBOARD_GUIDE.md").write_text("\n".join(doc) + "\n", encoding="utf-8")
    print("Wrote 4 dashboards, grafana_queries.sql, docs/DASHBOARD_GUIDE.md")


if __name__ == "__main__":
    main()
