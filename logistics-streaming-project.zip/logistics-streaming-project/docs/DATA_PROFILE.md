# Data profile: `logistics_streaming_master.csv`

Inspected in full before any code was written. The file is only ever **read**; nothing in this project modifies it.

| Item | Finding |
|---|---|
| Records × columns | **12,000 × 33** |
| Encoding / delimiter | UTF-8, comma, header row |
| Duplicate rows | 0 |
| Duplicate `order_id` | 0 (ORD-000001 … ORD-012000) → **primary key** |
| Missing values | Only `actual_delivery_time`: 4,512 blanks = every order whose status is not *Delivered* (In Transit 2,317 · Out for Delivery 1,234 · Delayed 732 · Cancelled 229). Legitimate → stored as NULL |
| Leading/trailing spaces | none |
| Row order | Not chronological (the producer sorts by order time by default) |

## Columns and types

| Column | Type stored in MySQL | Notes |
|---|---|---|
| order_id | VARCHAR(20) | unique |
| order_date | DATE | 2026-09-01 … 2026-09-30 (30 days) |
| order_time | TIME | 07:00 … 20:00 |
| customer_id | VARCHAR | 6,204 distinct |
| priority | VARCHAR | Standard 8,623 · Priority 2,636 · Express 741 |
| order_status | VARCHAR | Delivered 7,488 · In Transit 2,317 · Out for Delivery 1,234 · Delayed 732 · Cancelled 229 |
| warehouse_id | VARCHAR | WH-01 … WH-08 |
| hub | VARCHAR | HUB-01 … HUB-08 |
| city | VARCHAR | 12: Ahmedabad, Bengaluru, Chennai, Delhi, Gurugram, Hyderabad, Jaipur, Kolkata, Lucknow, Mumbai, Noida, Pune |
| zone | VARCHAR | 9 values (see data-quality note) |
| region | VARCHAR | North 3,979 · West 4,000 · South 3,026 · East 995 (consistent with city) |
| latitude / longitude | DECIMAL(9,6) | valid for all rows; each city's points fall in a ~0.16° box around that city |
| vehicle_id | VARCHAR | 350 distinct |
| vehicle_type | VARCHAR | Bike 4,551 · Van 3,874 · Mini Truck 2,365 · Truck 1,210 |
| driver_id | VARCHAR | 450 distinct |
| vehicle_capacity_kg | INT | Bike 20 · Van 250 · Mini Truck 800 · Truck 2,500 (1:1 with type) |
| vehicle_status | VARCHAR | On Delivery 4,283 · Maintenance 3,864 · Available 3,853 |
| driver_experience_years | DECIMAL(4,1) | 0.5 … 12.0 |
| delivery_distance_km | DECIMAL(7,2) | 2.01 … 55.00 |
| estimated_delivery_time | DATETIME | 2026-09-01 07:40 … 2026-09-30 22:45 |
| actual_delivery_time | DATETIME NULL | 2026-09-01 07:52 … 2026-09-30 22:42 |
| delay_minutes | INT | 0 … 105 (56.6 % are 0) |
| sla_breach | TINYINT 0/1 | source **Yes/No**: Yes 1,636 · No 10,364 |
| at_risk | TINYINT 0/1 | source **Yes/No**: Yes 2,244 · No 9,756 |
| eta_variance_minutes | INT | −10 … 83 |
| delay_reason | VARCHAR | None 6,780 · Traffic 3,928 · Road Condition 680 · Vehicle Issue 210 · Weather 205 · Address Issue 197 |
| delivery_attempts | INT | 1 (10,999) · 2 (651) · 3 (350) |
| speed_kmph | DECIMAL(6,1) | 8.0 … 62.4 |
| fuel_level_pct | DECIMAL(5,1) | 5 … 99 |
| route_condition | VARCHAR | Good 6,621 · Moderate 3,920 · Poor 1,459 |
| traffic_level | VARCHAR | Low 3,312 · Medium 4,848 · High 3,013 · Severe 827 |
| package_weight_kg | DECIMAL(8,2) | 0.20 … 44.99; never exceeds vehicle capacity |

## Business-logic checks (all pass)

* For delivered orders `actual − estimated = delay_minutes = eta_variance_minutes` (100 %).
* No ETA or actual time is earlier than the order time.
* `sla_breach = Yes` always has delay ≥ 16 min; `No` has delay ≤ 30 min, so the SLA has a grace window.
* `delay_reason = 'None'` always has `delay_minutes = 0` (9 rows have 0 delay but a reason recorded; kept as-is).
* `at_risk = Yes` occurs **only** for open orders (In Transit 1,493, Out for Delivery 751).

## Data-quality observations and handling

| Observation | Handling |
|---|---|
| `zone` does not match `city` (e.g. Mumbai rows are in zones Ahmedabad/Jaipur/Pune; Lucknow is in zone NCR) | Kept exactly as in the source. Dashboards filter by **city** and **region**, which are consistent. |
| The same `vehicle_id` appears with different types and statuses | Vehicle fields are treated as **per-order snapshots**; fleet analysis is by vehicle type, not a fixed vehicle register. |
| `sla_breach`, `at_risk` are text Yes/No | Processor maps Yes→1, No→0 (rejects anything else); MySQL `TINYINT` + CHECK (0,1); Grafana tests `= 1` and shows Yes/No with `IF()`. |
| `delay_reason` uses the word `None` for no delay | Kept as the literal category `None`; delay-reason charts exclude it. |
| Blank `actual_delivery_time` | Stored as NULL, shown as "-". |

## Fields NOT in the dataset (not invented)

Fuel consumption (litres/km), fuel or delivery cost, engine hours, driver ratings, customer ratings, named routes / road segments, a live vehicle GPS trail.
Replacements used: fuel **level** bands, derived **load utilization** (`package_weight_kg / vehicle_capacity_kg × 100`), derived **lanes** (`hub → city`) with traffic/road-condition breakdowns.

## Key for streaming

`event_id = "<run_id>|<pass_no>|<order_id>"` plus `UNIQUE (run_id, pass_no, order_id)`. Deterministic, so a re-delivered Kafka event can never create a second row. `pass_no` is always 1 in the default one-pass mode.
