# Dashboard guide

_Generated from `tools/build_dashboards.py` together with the dashboard JSON, so the SQL below is exactly what each panel runs._

## Common to all four dashboards

* **URL:** http://localhost:3000 → *Dashboards* → folder **Logistics Streaming Analytics**. Links to the other three dashboards are in the top-right of every dashboard.
* **Auto-refresh:** 5 s (change in the refresh picker; minimum allowed is 5 s).
* **Time picker:** default *Last 15 minutes*. It only affects panels titled **Live:** (they use `ingested_at`, the time the processor wrote the row, in UTC, displayed in your browser time zone). All other panels show **every record of the selected run** and use the **CSV event time** (`order_date` / `order_time`, Sep 2026, shown as written in the CSV).
* **Filters (dropdowns):** Run, Region, City (cascades from Region), Priority, Vehicle type, Order date. Each multi-select has an **All** option. How *All* is configured: *Include All option* = on, *Custom all value* = `'__ALL__'` (with the quotes), and every query uses `('__ALL__' IN (${city}) OR e.city IN (${city}))`. This keeps queries valid even before any data has arrived (an empty `IN ()` would be a SQL error).
* **Run filter:** *Latest run (auto)* always follows the newest run in `pipeline_runs`; older runs can be picked explicitly. After `reset_database.py` only the new run exists.
* **Yes/No fields:** `sla_breach`, `at_risk` are `Yes/No` in the CSV, 1/0 in MySQL, and shown as Yes/No again in tables via `IF(x = 1, 'Yes', 'No')`.

## 1. Delivery Operations Control Tower

**Problem statement:** How can operations managers monitor delivery workload, order status and current delivery performance?

**URL:** http://localhost:3000/d/logistics-ops-control-tower  ·  **File:** `grafana/dashboards/01_delivery_operations_control_tower.json`

### Total orders

* **Purpose:** Orders stored for the selected run and filters.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Grows while the producer is streaming; 12,000 when the full CSV has been processed (no filters).

```sql
SELECT COUNT(*) AS `Orders` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Processed events (run)

* **Purpose:** Kafka events the processor has handled for this run (inserted + rejected). Not affected by filters.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Should equal the source row count (12,000) at the end; compare with Total orders to spot rejects.

```sql
SELECT r.inserted_count + r.rejected_count AS `Processed` FROM pipeline_runs r WHERE r.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
```

### Stream progress

* **Purpose:** Share of the source CSV already processed for this run.
* **Visualization:** Stat  ·  **Unit:** `percent`  ·  **Thresholds:** orange (base), green ≥ 99.99  ·  **Legend:** auto (series = column names)
* **Interpretation:** Moves from 0 % to 100 % during the live demo.

```sql
SELECT ROUND(100 * (r.inserted_count + r.rejected_count) / NULLIF(r.source_rows, 0), 1) AS `Progress` FROM pipeline_runs r WHERE r.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
```

### On-time delivery %

* **Purpose:** Delivered orders that met the SLA (sla_breach = No) / all delivered orders.
* **Visualization:** Stat  ·  **Unit:** `percent`  ·  **Thresholds:** red (base), orange ≥ 80, green ≥ 88  ·  **Legend:** auto (series = column names)
* **Interpretation:** Below 88 % turns amber, below 80 % red. The source SLA allows small delays (up to ~15 min) without a breach.

```sql
SELECT ROUND(100 * SUM(e.order_status = 'Delivered' AND e.sla_breach = 0) / NULLIF(SUM(e.order_status = 'Delivered'), 0), 1) AS `On-time %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Delivered (completed)

* **Purpose:** Orders with order_status = Delivered.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** green (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Completed workload.

```sql
SELECT SUM(e.order_status = 'Delivered') AS `Delivered` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Active (in transit / out for delivery)

* **Purpose:** Orders still moving: In Transit + Out for Delivery.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Current open workload for the fleet.

```sql
SELECT SUM(e.order_status IN ('In Transit', 'Out for Delivery')) AS `Active` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Delayed (status)

* **Purpose:** Orders whose status is Delayed (not yet delivered).
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** orange (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Exceptions that need intervention.

```sql
SELECT SUM(e.order_status = 'Delayed') AS `Delayed` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Cancelled

* **Purpose:** Orders with status Cancelled.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** red (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Lost workload; watch for spikes in a city or hub.

```sql
SELECT SUM(e.order_status = 'Cancelled') AS `Cancelled` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Avg delivery distance

* **Purpose:** Mean delivery_distance_km.
* **Visualization:** Stat  ·  **Unit:** `lengthkm`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Longer average trips = heavier fleet load.

```sql
SELECT ROUND(AVG(e.delivery_distance_km), 1) AS `km` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Orders needing re-attempt

* **Purpose:** Orders with delivery_attempts > 1.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** orange (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Each re-attempt is extra cost and a customer-experience risk.

```sql
SELECT SUM(e.delivery_attempts > 1) AS `Re-attempts` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Avg delay (all orders)

* **Purpose:** Mean delay_minutes across all orders.
* **Visualization:** Stat  ·  **Unit:** `m`  ·  **Thresholds:** green (base), orange ≥ 10, red ≥ 20  ·  **Legend:** auto (series = column names)
* **Interpretation:** Headline delay level; detail on dashboard 2.

```sql
SELECT ROUND(AVG(e.delay_minutes), 1) AS `min` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### SLA breaches

* **Purpose:** Orders flagged sla_breach = Yes.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** red (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Root causes on dashboard 2.

```sql
SELECT SUM(e.sla_breach = 1) AS `Breaches` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Orders by delivery status

* **Purpose:** Status mix of the selected orders.
* **Visualization:** Pie / donut chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** In the full dataset ~62 % are Delivered, ~30 % still open (In Transit + Out for Delivery), ~6 % Delayed.

```sql
SELECT e.order_status AS `Status`, COUNT(*) AS `Orders` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.order_status ORDER BY `Orders` DESC
```

### Live: events arriving per 10 s, by status

* **Purpose:** Live arrival rate of records written by the stream processor (ingestion time).
* **Visualization:** Time series (ingestion time)  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Proves the pipeline is live: bars appear every refresh while producer.py runs and stop when it finishes.

```sql
SELECT $__timeGroupAlias(e.ingested_at, 10s), e.order_status AS metric, COUNT(*) AS value FROM delivery_events e WHERE $__timeFilter(e.ingested_at) AND e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY 1, 2 ORDER BY 1
```

### Daily order volume by status (event date)

* **Purpose:** Orders per order_date (event time from the CSV), split by status.
* **Visualization:** Bar chart (stacked)  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** With chronological streaming the bars fill from 1 Sep to 30 Sep as the demo runs.

```sql
SELECT DATE_FORMAT(e.order_date, '%d %b') AS `Day`, SUM(e.order_status = 'Delivered') AS `Delivered`, SUM(e.order_status = 'In Transit') AS `In Transit`, SUM(e.order_status = 'Out for Delivery') AS `Out for Delivery`, SUM(e.order_status = 'Delayed') AS `Delayed`, SUM(e.order_status = 'Cancelled') AS `Cancelled` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.order_date ORDER BY e.order_date
```

### Order workload by hour of day

* **Purpose:** Orders by order_time hour (07–20 h in the source).
* **Visualization:** Bar chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Peak hours are where dispatch capacity is most likely to bottleneck.

```sql
SELECT LPAD(HOUR(e.order_time), 2, '0') AS `Hour`, COUNT(*) AS `Orders` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY `Hour` ORDER BY `Hour`
```

### Bottleneck finder: hub workload and performance

* **Purpose:** Workload, open backlog and service level per hub.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Hubs at the top hold the largest share of unfinished orders; combine with SLA breach % to choose where to add riders.

```sql
SELECT e.hub AS `Hub`, COUNT(*) AS `Orders`, SUM(e.order_status IN ('In Transit', 'Out for Delivery')) AS `Active`, SUM(e.order_status = 'Delayed') AS `Delayed status`, ROUND(100 * SUM(e.order_status IN ('In Transit', 'Out for Delivery') OR e.order_status = 'Delayed') / COUNT(*), 1) AS `Open backlog %`, ROUND(100 * AVG(e.sla_breach), 1) AS `SLA breach %`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, SUM(e.delivery_attempts > 1) AS `Re-attempts` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.hub ORDER BY `Open backlog %` DESC
```

### Open backlog by city (active + delayed orders)

* **Purpose:** Orders not yet delivered or cancelled, per city.
* **Visualization:** Bar gauge (one bar per row)  ·  **Unit:** `none`  ·  **Thresholds:** blue (base), orange ≥ 360, red ≥ 375  ·  **Legend:** auto (series = column names)
* **Interpretation:** Cities with the longest bars need the most dispatch attention right now.

```sql
SELECT e.city AS `City`, SUM(e.order_status IN ('In Transit', 'Out for Delivery') OR e.order_status = 'Delayed') AS `Open orders` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.city ORDER BY `Open orders` DESC
```

### Latest orders streamed (newest first)

* **Purpose:** The 50 most recently ingested orders with key operational fields.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Watch new orders appear at the top on every refresh during the demo.

```sql
SELECT DATE_FORMAT(e.ingested_at, '%H:%i:%s') AS `Ingested (UTC)`, e.order_id AS `Order`, DATE_FORMAT(e.order_ts, '%Y-%m-%d %H:%i') AS `Order time`, e.city AS `City`, e.hub AS `Hub`, e.priority AS `Priority`, e.order_status AS `Status`, e.vehicle_type AS `Vehicle`, e.delivery_distance_km AS `Distance (km)`, DATE_FORMAT(e.estimated_delivery_time, '%m-%d %H:%i') AS `ETA`, COALESCE(DATE_FORMAT(e.actual_delivery_time, '%m-%d %H:%i'), '-') AS `Delivered at`, e.delay_minutes AS `Delay (min)`, IF(e.sla_breach = 1, 'Yes', 'No') AS `SLA breach`, IF(e.at_risk = 1, 'Yes', 'No') AS `At risk` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) ORDER BY e.ingested_at DESC, e.source_row_number DESC LIMIT 50
```

## 2. SLA Compliance and Delivery Delays

**Problem statement:** Where and why are delivery commitments being missed?

**URL:** http://localhost:3000/d/logistics-sla-delays  ·  **File:** `grafana/dashboards/02_sla_compliance_and_delays.json`

### SLA breaches

* **Purpose:** Orders with sla_breach = Yes.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** red (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Absolute count of missed commitments.

```sql
SELECT SUM(e.sla_breach = 1) AS `Breaches` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### SLA breach rate

* **Purpose:** Breaches / all orders.
* **Visualization:** Stat  ·  **Unit:** `percent`  ·  **Thresholds:** green (base), orange ≥ 14, red ≥ 18  ·  **Legend:** auto (series = column names)
* **Interpretation:** About 13.6 % on the full dataset; amber from 14 %, red from 18 %.

```sql
SELECT ROUND(100 * AVG(e.sla_breach), 1) AS `Breach %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Avg delay (all orders)

* **Purpose:** Mean delay_minutes including on-time orders.
* **Visualization:** Stat  ·  **Unit:** `m`  ·  **Thresholds:** green (base), orange ≥ 10, red ≥ 20  ·  **Legend:** auto (series = column names)
* **Interpretation:** Overall delay level.

```sql
SELECT ROUND(AVG(e.delay_minutes), 1) AS `Avg` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Avg delay when late

* **Purpose:** Mean delay of orders with delay_minutes > 0.
* **Visualization:** Stat  ·  **Unit:** `m`  ·  **Thresholds:** orange (base), red ≥ 30  ·  **Legend:** auto (series = column names)
* **Interpretation:** How late the late orders are.

```sql
SELECT ROUND(AVG(e.delay_minutes), 1) AS `Avg` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) AND e.delay_minutes > 0
```

### Max delay

* **Purpose:** Worst single delay.
* **Visualization:** Stat  ·  **Unit:** `m`  ·  **Thresholds:** orange (base), red ≥ 60  ·  **Legend:** auto (series = column names)
* **Interpretation:** Outlier severity; see the worst-breaches table.

```sql
SELECT MAX(e.delay_minutes) AS `Max` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Orders with any delay

* **Purpose:** Share of orders with delay_minutes > 0.
* **Visualization:** Stat  ·  **Unit:** `percent`  ·  **Thresholds:** green (base), orange ≥ 35, red ≥ 50  ·  **Legend:** auto (series = column names)
* **Interpretation:** Includes delays still inside the SLA grace window.

```sql
SELECT ROUND(100 * AVG(e.delay_minutes > 0), 1) AS `%` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Daily SLA breach rate (event date)

* **Purpose:** Breach rate per order_date.
* **Visualization:** Bar chart  ·  **Unit:** `percent`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Spikes point to specific days (weather, events) worth investigating.

```sql
SELECT DATE_FORMAT(e.order_date, '%d %b') AS `Day`, ROUND(100 * AVG(e.sla_breach), 1) AS `Breach rate %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.order_date ORDER BY e.order_date
```

### Daily average and maximum delay (event date)

* **Purpose:** Delay trend over the order dates.
* **Visualization:** Bar chart  ·  **Unit:** `m`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** A rising average signals systemic problems; isolated max spikes are outliers.

```sql
SELECT DATE_FORMAT(e.order_date, '%d %b') AS `Day`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, MAX(e.delay_minutes) AS `Max delay (min)` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.order_date ORDER BY e.order_date
```

### Live: SLA breach rate of arriving orders (per 30 s)

* **Purpose:** Breach rate of the records ingested in each 30-second window.
* **Visualization:** Time series (ingestion time)  ·  **Unit:** `percent`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Lets you watch compliance of the incoming stream in real time.

```sql
SELECT $__timeGroupAlias(e.ingested_at, 30s), ROUND(100 * AVG(e.sla_breach), 1) AS `Breach rate %` FROM delivery_events e WHERE $__timeFilter(e.ingested_at) AND e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY 1 ORDER BY 1
```

### SLA breach rate by city

* **Purpose:** Breach rate per city, worst first.
* **Visualization:** Bar gauge (one bar per row)  ·  **Unit:** `percent`  ·  **Thresholds:** green (base), orange ≥ 14, red ≥ 15  ·  **Legend:** auto (series = column names)
* **Interpretation:** Pune and Noida (~15 %) lead; Gurugram is best (~12 %). Spread is narrow, so causes are mostly traffic/road related rather than city-specific.

```sql
SELECT e.city AS `City`, ROUND(100 * AVG(e.sla_breach), 1) AS `Breach %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.city ORDER BY `Breach %` DESC
```

### SLA performance by region

* **Purpose:** Regional SLA comparison.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Compare breach rate against volume to prioritise regional action.

```sql
SELECT e.region AS `Region`, COUNT(*) AS `Orders`, SUM(e.sla_breach) AS `Breaches`, ROUND(100 * AVG(e.sla_breach), 1) AS `Breach %`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, MAX(e.delay_minutes) AS `Max delay (min)`, ROUND(100 * AVG(e.at_risk), 1) AS `At-risk %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.region ORDER BY `Breach %` DESC
```

### Delay reasons (delayed orders only)

* **Purpose:** Why orders were delayed (delay_reason, excluding 'None').
* **Visualization:** Pie / donut chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Traffic dominates delay volume in this dataset.

```sql
SELECT e.delay_reason AS `Reason`, COUNT(*) AS `Orders` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) AND e.delay_reason <> 'None' GROUP BY e.delay_reason ORDER BY `Orders` DESC
```

### Breached vs within SLA by delay reason

* **Purpose:** For each reason, how many delays turned into SLA breaches.
* **Visualization:** Bar chart (stacked)  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Traffic causes the most breaches by volume, but Vehicle Issue, Weather and Address Issue break the SLA ~2 times in 3.

```sql
SELECT e.delay_reason AS `Reason`, SUM(e.sla_breach = 1) AS `Breached`, SUM(e.sla_breach = 0) AS `Within SLA` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) AND e.delay_reason <> 'None' GROUP BY e.delay_reason ORDER BY `Breached` DESC
```

### Traffic level impact

* **Purpose:** Average delay and breach rate by traffic_level.
* **Visualization:** Bar chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** High/Severe traffic raises average delay from ~3 min to ~23-24 min and breach rate from ~4 % to 33-38 %: the single biggest driver.

```sql
SELECT e.traffic_level AS `Traffic`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, ROUND(100 * AVG(e.sla_breach), 1) AS `Breach rate %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.traffic_level ORDER BY FIELD(e.traffic_level, 'Low', 'Medium', 'High', 'Severe')
```

### Route condition impact

* **Purpose:** Average delay and breach rate by route_condition.
* **Visualization:** Bar chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Poor roads nearly triple average delay (~23 min vs ~8) and breach rate (~31 % vs ~11 %): re-routing candidates.

```sql
SELECT e.route_condition AS `Route condition`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, ROUND(100 * AVG(e.sla_breach), 1) AS `Breach rate %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.route_condition ORDER BY FIELD(e.route_condition, 'Good', 'Moderate', 'Poor')
```

### SLA comparison by priority

* **Purpose:** SLA outcome per service level.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Express (~26 %) and Priority (~22 %) orders breach far more often than Standard (~10 %): the premium promise is the weakest link.

```sql
SELECT e.priority AS `Priority`, COUNT(*) AS `Orders`, SUM(e.sla_breach) AS `Breaches`, ROUND(100 * AVG(e.sla_breach), 1) AS `Breach %`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, MAX(e.delay_minutes) AS `Max delay (min)` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.priority ORDER BY FIELD(e.priority, 'Express', 'Priority', 'Standard')
```

### Delay distribution

* **Purpose:** Orders per delay band.
* **Visualization:** Bar chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Most orders are on time; the 31+ min tail drives almost all breaches.

```sql
SELECT b.band AS `Delay band`, COUNT(*) AS `Orders` FROM (SELECT CASE WHEN e.delay_minutes = 0 THEN '0 on time' WHEN e.delay_minutes <= 15 THEN '1-15 min' WHEN e.delay_minutes <= 30 THEN '16-30 min' WHEN e.delay_minutes <= 60 THEN '31-60 min' ELSE '60+ min' END AS band FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))) b GROUP BY b.band ORDER BY b.band
```

### Worst SLA breaches (top 25)

* **Purpose:** Largest breaches with their context.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Use for root-cause review of individual failures.

```sql
SELECT e.order_id AS `Order`, e.city AS `City`, e.hub AS `Hub`, e.priority AS `Priority`, e.order_status AS `Status`, e.vehicle_type AS `Vehicle`, e.traffic_level AS `Traffic`, e.route_condition AS `Route`, e.delay_reason AS `Reason`, e.delay_minutes AS `Delay (min)`, DATE_FORMAT(e.estimated_delivery_time, '%Y-%m-%d %H:%i') AS `ETA` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) AND e.sla_breach = 1 ORDER BY e.delay_minutes DESC, e.order_id LIMIT 25
```

## 3. Fleet and Resource Efficiency

**Problem statement:** How efficiently are vehicles and delivery resources being utilized?

**URL:** http://localhost:3000/d/logistics-fleet-efficiency  ·  **File:** `grafana/dashboards/03_fleet_and_resource_efficiency.json`

### Vehicles used

* **Purpose:** Distinct vehicle_id values.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Fleet size engaged for the filtered orders.

```sql
SELECT COUNT(DISTINCT e.vehicle_id) AS `Vehicles` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Drivers used

* **Purpose:** Distinct driver_id values.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Workforce engaged.

```sql
SELECT COUNT(DISTINCT e.driver_id) AS `Drivers` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Avg speed

* **Purpose:** Mean speed_kmph.
* **Visualization:** Stat  ·  **Unit:** `velocitykmh`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Lower speed in a city = congestion or poor routes.

```sql
SELECT ROUND(AVG(e.speed_kmph), 1) AS `km/h` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Avg fuel level

* **Purpose:** Mean fuel_level_pct snapshot (not consumption).
* **Visualization:** Stat  ·  **Unit:** `percent`  ·  **Thresholds:** red (base), orange ≥ 25, green ≥ 40  ·  **Legend:** auto (series = column names)
* **Interpretation:** Proxy for refuelling pressure.

```sql
SELECT ROUND(AVG(e.fuel_level_pct), 1) AS `%` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Low-fuel orders (<20 %)

* **Purpose:** Orders served by a vehicle below 20 % fuel.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** orange (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Breakdown / detour risk; schedule refuelling.

```sql
SELECT SUM(e.fuel_level_pct < 20) AS `Orders` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Avg load utilization

* **Purpose:** DERIVED: mean package weight / vehicle capacity.
* **Visualization:** Stat  ·  **Unit:** `percent`  ·  **Thresholds:** blue (base), green ≥ 20, orange ≥ 70, red ≥ 90  ·  **Legend:** auto (series = column names)
* **Interpretation:** Very low values mean oversized vehicles for the parcel.

```sql
SELECT ROUND(AVG(e.load_utilization_pct), 1) AS `%` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Vehicle-type comparison

* **Purpose:** Side-by-side efficiency profile of each vehicle type.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Bikes use ~43 % of their 20 kg limit on average, vans ~9 %, mini trucks ~3 %, trucks under 1 %: heavy vehicles are badly under-loaded (right-sizing opportunity). Delay and breach rates are almost identical across types.

```sql
SELECT e.vehicle_type AS `Vehicle type`, MAX(e.vehicle_capacity_kg) AS `Capacity (kg)`, COUNT(*) AS `Orders`, ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS `Share of orders %`, ROUND(AVG(e.delivery_distance_km), 1) AS `Avg distance (km)`, ROUND(AVG(e.speed_kmph), 1) AS `Avg speed (km/h)`, ROUND(AVG(e.package_weight_kg), 2) AS `Avg package (kg)`, MAX(e.package_weight_kg) AS `Max package (kg)`, ROUND(AVG(e.load_utilization_pct), 1) AS `Avg load util %`, ROUND(AVG(e.fuel_level_pct), 1) AS `Avg fuel %`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, ROUND(100 * AVG(e.sla_breach), 1) AS `SLA breach %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.vehicle_type ORDER BY FIELD(e.vehicle_type, 'Bike', 'Van', 'Mini Truck', 'Truck')
```

### Delay and SLA breach by vehicle type

* **Purpose:** Service performance per vehicle type.
* **Visualization:** Bar chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** All four types sit at ~9.6-9.8 min average delay and 13-14 % breach rate: vehicle type is not what drives SLA misses.

```sql
SELECT e.vehicle_type AS `Vehicle type`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, ROUND(100 * AVG(e.sla_breach), 1) AS `SLA breach %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.vehicle_type ORDER BY FIELD(e.vehicle_type, 'Bike', 'Van', 'Mini Truck', 'Truck')
```

### Vehicle status at order time

* **Purpose:** vehicle_status snapshot recorded with each order.
* **Visualization:** Pie / donut chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** A high Maintenance share signals fleet availability risk.

```sql
SELECT e.vehicle_status AS `Vehicle status`, COUNT(*) AS `Orders` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.vehicle_status ORDER BY `Orders` DESC
```

### Fuel level bands by vehicle type

* **Purpose:** Distribution of fuel_level_pct snapshots per vehicle type (fuel level, NOT consumption).
* **Visualization:** Bar chart (stacked)  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Large 'Low' bars point to refuelling planning gaps.

```sql
SELECT e.vehicle_type AS `Vehicle type`, SUM(e.fuel_level_pct < 20) AS `Low (<20%)`, SUM(e.fuel_level_pct >= 20 AND e.fuel_level_pct < 50) AS `Medium (20-50%)`, SUM(e.fuel_level_pct >= 50) AS `High (50%+)` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.vehicle_type ORDER BY FIELD(e.vehicle_type, 'Bike', 'Van', 'Mini Truck', 'Truck')
```

### Driver experience vs performance

* **Purpose:** Delay, breach rate and speed by driver_experience_years band (orders shown in tooltip/legend).
* **Visualization:** Bar chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** In this dataset delay (~9.4-9.9 min) and breach rate (~13-14 %) are nearly flat across experience bands, so experience is not the main driver of lateness; traffic and road condition are (see dashboard 2).

```sql
SELECT b.band AS `Experience`, COUNT(*) AS `Orders`, ROUND(AVG(b.delay_minutes), 1) AS `Avg delay (min)`, ROUND(100 * AVG(b.sla_breach), 1) AS `SLA breach %`, ROUND(AVG(b.speed_kmph), 1) AS `Avg speed (km/h)` FROM (SELECT CASE WHEN e.driver_experience_years < 2 THEN '0-2 yrs' WHEN e.driver_experience_years < 5 THEN '2-5 yrs' WHEN e.driver_experience_years < 8 THEN '5-8 yrs' ELSE '8-12 yrs' END AS band, e.delay_minutes, e.sla_breach, e.speed_kmph FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))) b GROUP BY b.band ORDER BY b.band
```

### Load utilization by vehicle type (derived)

* **Purpose:** Package weight as % of vehicle capacity.
* **Visualization:** Bar chart  ·  **Unit:** `percent`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Bikes average ~43 % (max 85 %) of their 20 kg limit; vans ~9 %, mini trucks ~3 %, trucks under 1 % of 2,500 kg. Heavy vehicles are under-loaded.

```sql
SELECT e.vehicle_type AS `Vehicle type`, ROUND(AVG(e.load_utilization_pct), 2) AS `Avg utilization %`, ROUND(MAX(e.load_utilization_pct), 2) AS `Max utilization %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.vehicle_type ORDER BY FIELD(e.vehicle_type, 'Bike', 'Van', 'Mini Truck', 'Truck')
```

### Package weight vs vehicle capacity

* **Purpose:** Capacity against actual package weights (log scale).
* **Visualization:** Bar chart  ·  **Unit:** `masskg`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Gap between bars = unused capacity.

```sql
SELECT e.vehicle_type AS `Vehicle type`, MAX(e.vehicle_capacity_kg) AS `Capacity (kg)`, ROUND(AVG(e.package_weight_kg), 1) AS `Avg package (kg)`, MAX(e.package_weight_kg) AS `Max package (kg)` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.vehicle_type ORDER BY FIELD(e.vehicle_type, 'Bike', 'Van', 'Mini Truck', 'Truck')
```

### Average speed by traffic level and vehicle type

* **Purpose:** Mean speed_kmph per traffic level for each vehicle type.
* **Visualization:** Bar chart  ·  **Unit:** `velocitykmh`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Which vehicle class keeps moving in heavy traffic (useful for congested-city allocation).

```sql
SELECT e.traffic_level AS `Traffic`, ROUND(AVG(CASE WHEN e.vehicle_type = 'Bike' THEN e.speed_kmph END), 1) AS `Bike`, ROUND(AVG(CASE WHEN e.vehicle_type = 'Van' THEN e.speed_kmph END), 1) AS `Van`, ROUND(AVG(CASE WHEN e.vehicle_type = 'Mini Truck' THEN e.speed_kmph END), 1) AS `Mini Truck`, ROUND(AVG(CASE WHEN e.vehicle_type = 'Truck' THEN e.speed_kmph END), 1) AS `Truck` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.traffic_level ORDER BY FIELD(e.traffic_level, 'Low', 'Medium', 'High', 'Severe')
```

### Distance band vs delay and speed

* **Purpose:** Effect of trip length on delay and speed.
* **Visualization:** Bar chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Shows whether long trips need different vehicle allocation.

```sql
SELECT b.band AS `Distance`, ROUND(AVG(b.delay_minutes), 1) AS `Avg delay (min)`, ROUND(AVG(b.speed_kmph), 1) AS `Avg speed (km/h)` FROM (SELECT CASE WHEN e.delivery_distance_km < 15 THEN '1) <15 km' WHEN e.delivery_distance_km < 30 THEN '2) 15-30 km' WHEN e.delivery_distance_km < 45 THEN '3) 30-45 km' ELSE '4) 45+ km' END AS band, e.delay_minutes, e.speed_kmph FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))) b GROUP BY b.band ORDER BY b.band
```

### Busiest drivers (top 15 by orders)

* **Purpose:** Driver workload and outcomes.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Balance load away from overworked drivers with high breach %.

```sql
SELECT e.driver_id AS `Driver`, COUNT(*) AS `Orders`, ROUND(SUM(e.delivery_distance_km), 1) AS `Total km`, ROUND(AVG(e.delay_minutes), 1) AS `Avg delay (min)`, ROUND(100 * AVG(e.sla_breach), 1) AS `SLA breach %`, ROUND(AVG(e.driver_experience_years), 1) AS `Avg experience (yrs)`, COUNT(DISTINCT e.vehicle_type) AS `Vehicle types` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.driver_id ORDER BY `Orders` DESC, `Driver` LIMIT 15
```

## 4. Last-Mile Risk and Route Intelligence

**Problem statement:** Which orders, routes and locations are most at risk of late delivery?

**URL:** http://localhost:3000/d/logistics-risk-route  ·  **File:** `grafana/dashboards/04_last_mile_risk_and_route_intelligence.json`

### Open orders

* **Purpose:** In Transit + Out for Delivery.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Base for risk rates.

```sql
SELECT SUM(e.order_status IN ('In Transit', 'Out for Delivery')) AS `Open` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### At-risk orders

* **Purpose:** Orders with source flag at_risk = Yes.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** red (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Orders likely to be late if nothing changes.

```sql
SELECT SUM(e.at_risk = 1) AS `At risk` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### At-risk share of open orders

* **Purpose:** At-risk / open orders.
* **Visualization:** Stat  ·  **Unit:** `percent`  ·  **Thresholds:** green (base), orange ≥ 50, red ≥ 65  ·  **Legend:** auto (series = column names)
* **Interpretation:** About 63 % on the full data; amber above 50 %, red above 65 %.

```sql
SELECT ROUND(100 * SUM(e.at_risk = 1) / NULLIF(SUM(e.order_status IN ('In Transit', 'Out for Delivery')), 0), 1) AS `%` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Avg ETA variance (open)

* **Purpose:** Mean projected ETA variance of open orders.
* **Visualization:** Stat  ·  **Unit:** `m`  ·  **Thresholds:** green (base), orange ≥ 10, red ≥ 20  ·  **Legend:** auto (series = column names)
* **Interpretation:** Positive = running behind ETA.

```sql
SELECT ROUND(AVG(e.eta_variance_minutes), 1) AS `min` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) AND e.order_status IN ('In Transit', 'Out for Delivery')
```

### Max ETA variance (open)

* **Purpose:** Worst projected variance.
* **Visualization:** Stat  ·  **Unit:** `m`  ·  **Thresholds:** orange (base), red ≥ 30  ·  **Legend:** auto (series = column names)
* **Interpretation:** Top of the watch-list below.

```sql
SELECT MAX(e.eta_variance_minutes) AS `min` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) AND e.order_status IN ('In Transit', 'Out for Delivery')
```

### At-risk Express + Priority

* **Purpose:** At-risk orders on premium service levels.
* **Visualization:** Stat  ·  **Unit:** `none`  ·  **Thresholds:** orange (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Highest-value interventions: escalate these first.

```sql
SELECT SUM(e.at_risk = 1 AND e.priority IN ('Express', 'Priority')) AS `Orders` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day}))
```

### Map: at-risk open orders (colour = ETA variance)

* **Purpose:** Location (source latitude/longitude) of each at-risk order.
* **Visualization:** Geomap (markers)  ·  **Unit:** `m`  ·  **Thresholds:** green (base), orange ≥ 15, red ≥ 30  ·  **Legend:** auto (series = column names)
* **Interpretation:** Clusters show where to send support riders; red dots are the furthest behind ETA.

```sql
SELECT e.latitude AS `latitude`, e.longitude AS `longitude`, e.order_id AS `Order`, e.city AS `City`, e.priority AS `Priority`, e.traffic_level AS `Traffic`, e.eta_variance_minutes AS `ETA variance (min)` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) AND e.at_risk = 1
```

### At-risk share of open orders by city

* **Purpose:** Risk rate per city.
* **Visualization:** Bar gauge (one bar per row)  ·  **Unit:** `percent`  ·  **Thresholds:** green (base), orange ≥ 50, red ≥ 65  ·  **Legend:** auto (series = column names)
* **Interpretation:** Cities at the top need proactive customer communication and re-routing.

```sql
SELECT e.city AS `City`, ROUND(100 * SUM(e.at_risk = 1) / NULLIF(SUM(e.order_status IN ('In Transit', 'Out for Delivery')), 0), 1) AS `At-risk %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.city ORDER BY `At-risk %` DESC
```

### Risk by region

* **Purpose:** Regional risk comparison.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Regional managers can compare exposure on one line each.

```sql
SELECT e.region AS `Region`, SUM(e.order_status IN ('In Transit', 'Out for Delivery')) AS `Open`, SUM(e.at_risk = 1) AS `At risk`, ROUND(100 * SUM(e.at_risk = 1) / NULLIF(SUM(e.order_status IN ('In Transit', 'Out for Delivery')), 0), 1) AS `At-risk %`, ROUND(AVG(CASE WHEN e.order_status IN ('In Transit', 'Out for Delivery') THEN e.eta_variance_minutes END), 1) AS `Avg ETA var (open, min)` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.region ORDER BY `At-risk %` DESC
```

### Priority-wise risk

* **Purpose:** Open vs at-risk orders per priority.
* **Visualization:** Bar chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** A large at-risk bar on Express threatens the premium promise.

```sql
SELECT e.priority AS `Priority`, SUM(e.order_status IN ('In Transit', 'Out for Delivery')) AS `Open`, SUM(e.at_risk = 1) AS `At risk` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.priority ORDER BY FIELD(e.priority, 'Express', 'Priority', 'Standard')
```

### Risk matrix: traffic level x route condition (at-risk % of open)

* **Purpose:** At-risk share for each combination of traffic_level and route_condition.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** The bottom-right cells (severe traffic, poor roads) are the riskiest route conditions.

```sql
SELECT e.traffic_level AS `Traffic`, ROUND(100 * SUM(e.at_risk = 1 AND e.route_condition = 'Good') / NULLIF(SUM(e.order_status IN ('In Transit', 'Out for Delivery') AND e.route_condition = 'Good'), 0), 1) AS `Good road`, ROUND(100 * SUM(e.at_risk = 1 AND e.route_condition = 'Moderate') / NULLIF(SUM(e.order_status IN ('In Transit', 'Out for Delivery') AND e.route_condition = 'Moderate'), 0), 1) AS `Moderate road`, ROUND(100 * SUM(e.at_risk = 1 AND e.route_condition = 'Poor') / NULLIF(SUM(e.order_status IN ('In Transit', 'Out for Delivery') AND e.route_condition = 'Poor'), 0), 1) AS `Poor road` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.traffic_level ORDER BY FIELD(e.traffic_level, 'Low', 'Medium', 'High', 'Severe')
```

### ETA variance distribution (open orders)

* **Purpose:** How far behind ETA the open orders are, and how many are flagged.
* **Visualization:** Bar chart  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Shows how the source at_risk flag lines up with projected lateness.

```sql
SELECT b.band AS `ETA variance`, COUNT(*) AS `Open orders`, SUM(b.at_risk) AS `Of which at risk` FROM (SELECT CASE WHEN e.eta_variance_minutes < 0 THEN '1) ahead (<0)' WHEN e.eta_variance_minutes = 0 THEN '2) on ETA' WHEN e.eta_variance_minutes <= 15 THEN '3) 1-15 min' WHEN e.eta_variance_minutes <= 30 THEN '4) 16-30 min' ELSE '5) 30+ min' END AS band, e.at_risk FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) AND e.order_status IN ('In Transit', 'Out for Delivery')) b GROUP BY b.band ORDER BY b.band
```

### Live: at-risk orders arriving (per 30 s)

* **Purpose:** Open and at-risk orders among records ingested in each 30-second window.
* **Visualization:** Time series (ingestion time)  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Live view of the risk flowing into the control room.

```sql
SELECT $__timeGroupAlias(e.ingested_at, 30s), SUM(e.order_status IN ('In Transit', 'Out for Delivery')) AS `Open orders`, SUM(e.at_risk = 1) AS `At-risk orders` FROM delivery_events e WHERE $__timeFilter(e.ingested_at) AND e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY 1 ORDER BY 1
```

### Lane comparison: hub → city (derived lanes, top 20 by at-risk orders)

* **Purpose:** Risk per hub-to-city lane (derived, the CSV has no route ID).
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Lanes with high at-risk count AND high heavy-traffic share are re-routing candidates.

```sql
SELECT CONCAT(e.hub, ' → ', e.city) AS `Lane (derived)`, SUM(e.order_status IN ('In Transit', 'Out for Delivery')) AS `Open`, SUM(e.at_risk = 1) AS `At risk`, ROUND(100 * SUM(e.at_risk = 1) / NULLIF(SUM(e.order_status IN ('In Transit', 'Out for Delivery')), 0), 1) AS `At-risk %`, ROUND(AVG(CASE WHEN e.order_status IN ('In Transit', 'Out for Delivery') THEN e.eta_variance_minutes END), 1) AS `Avg ETA var (min)`, ROUND(AVG(e.delivery_distance_km), 1) AS `Avg distance (km)`, ROUND(100 * AVG(e.traffic_level IN ('High', 'Severe')), 1) AS `Heavy traffic %` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) GROUP BY e.hub, e.city ORDER BY `At risk` DESC, `Lane (derived)` LIMIT 20
```

### At-risk watch-list (top 50 by ETA variance)

* **Purpose:** At-risk orders sorted by how far behind ETA they are.
* **Visualization:** Table  ·  **Unit:** `none`  ·  **Thresholds:** blue (base)  ·  **Legend:** auto (series = column names)
* **Interpretation:** Call-list for the dispatch team.

```sql
SELECT e.order_id AS `Order`, e.city AS `City`, e.hub AS `Hub`, e.priority AS `Priority`, e.order_status AS `Status`, e.vehicle_type AS `Vehicle`, e.traffic_level AS `Traffic`, e.route_condition AS `Route`, e.delivery_distance_km AS `Distance (km)`, DATE_FORMAT(e.estimated_delivery_time, '%Y-%m-%d %H:%i') AS `ETA`, e.eta_variance_minutes AS `ETA variance (min)` FROM delivery_events e WHERE e.run_id = IF('${run}' = 'latest', (SELECT r.run_id FROM pipeline_runs r WHERE r.run_id <> 'UNKNOWN' ORDER BY r.started_at DESC LIMIT 1), '${run}')
  AND ('__ALL__' IN (${region}) OR e.region IN (${region}))
  AND ('__ALL__' IN (${city}) OR e.city IN (${city}))
  AND ('__ALL__' IN (${priority}) OR e.priority IN (${priority}))
  AND ('__ALL__' IN (${vehicle_type}) OR e.vehicle_type IN (${vehicle_type}))
  AND ('__ALL__' IN (${order_day}) OR DATE_FORMAT(e.order_date, '%Y-%m-%d') IN (${order_day})) AND e.at_risk = 1 ORDER BY e.eta_variance_minutes DESC, FIELD(e.priority, 'Express', 'Priority', 'Standard'), e.order_id LIMIT 50
```

