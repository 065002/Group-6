-- ============================================================================
-- Schema for database `logistics_streaming_project`
-- Idempotent: safe to run many times (CREATE ... IF NOT EXISTS only).
--  * Docker runs it automatically the FIRST time the MySQL volume is created
--    (inside MYSQL_DATABASE).
--  * `python init_schema.py` applies it again at any time from Windows.
-- Nothing in this file ever drops or deletes data.
-- ============================================================================

-- One row per streaming run (batch). Counters are updated by processor.py in
-- the SAME transaction as the rows they count, so they never drift.
CREATE TABLE IF NOT EXISTS pipeline_runs (
    run_id                 VARCHAR(64)   NOT NULL,
    source_file            VARCHAR(255)  NULL,
    source_rows            INT           NULL COMMENT 'rows in the CSV (from producer run_start)',
    source_sha256          CHAR(64)      NULL,
    stream_order           VARCHAR(20)   NULL,
    stream_interval_ms     INT           NULL,
    loop_mode              TINYINT(1)    NOT NULL DEFAULT 0,
    status                 VARCHAR(20)   NOT NULL DEFAULT 'RUNNING'
                           COMMENT 'RUNNING | PUBLISHED | COMPLETED | INCOMPLETE',
    published_count        INT           NULL COMMENT 'events the producer confirmed (from run_end)',
    producer_complete      TINYINT(1)    NULL COMMENT '1 = producer published every source row',
    inserted_count         INT           NOT NULL DEFAULT 0,
    duplicate_count        INT           NOT NULL DEFAULT 0,
    rejected_count         INT           NOT NULL DEFAULT 0,
    started_at             DATETIME(3)   NOT NULL COMMENT 'UTC',
    producer_finished_at   DATETIME(3)   NULL     COMMENT 'UTC',
    completed_at           DATETIME(3)   NULL     COMMENT 'UTC',
    updated_at             DATETIME(3)   NOT NULL COMMENT 'UTC',
    PRIMARY KEY (run_id),
    KEY idx_runs_started (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row per accepted source record per run.
-- Deterministic key: event_id = "<run_id>|<pass_no>|<order_id>", plus a UNIQUE
-- constraint on (run_id, pass_no, order_id). Kafka redeliveries can never
-- create a second row.
CREATE TABLE IF NOT EXISTS delivery_events (
    event_id                 VARCHAR(120)  NOT NULL,
    run_id                   VARCHAR(64)   NOT NULL,
    pass_no                  INT           NOT NULL DEFAULT 1 COMMENT '1 in default one-pass mode',
    source_row_number        INT           NOT NULL COMMENT '1-based data row number in the CSV',

    -- ---- source columns (all 33, same names as the CSV) ----
    order_id                 VARCHAR(20)   NOT NULL,
    order_date               DATE          NOT NULL,
    order_time               TIME          NOT NULL,
    customer_id              VARCHAR(20)   NOT NULL,
    priority                 VARCHAR(20)   NOT NULL,
    order_status             VARCHAR(30)   NOT NULL,
    warehouse_id             VARCHAR(20)   NOT NULL,
    hub                      VARCHAR(20)   NOT NULL,
    city                     VARCHAR(50)   NOT NULL,
    zone                     VARCHAR(50)   NOT NULL,
    region                   VARCHAR(20)   NOT NULL,
    latitude                 DECIMAL(9,6)  NOT NULL,
    longitude                DECIMAL(9,6)  NOT NULL,
    vehicle_id               VARCHAR(20)   NOT NULL,
    vehicle_type             VARCHAR(20)   NOT NULL,
    driver_id                VARCHAR(20)   NOT NULL,
    vehicle_capacity_kg      INT           NOT NULL,
    vehicle_status           VARCHAR(20)   NOT NULL,
    driver_experience_years  DECIMAL(4,1)  NOT NULL,
    delivery_distance_km     DECIMAL(7,2)  NOT NULL,
    estimated_delivery_time  DATETIME      NOT NULL,
    actual_delivery_time     DATETIME      NULL COMMENT 'NULL = not delivered yet / cancelled (blank in CSV)',
    delay_minutes            INT           NOT NULL,
    sla_breach               TINYINT(1)    NOT NULL COMMENT 'CSV Yes=1, No=0',
    at_risk                  TINYINT(1)    NOT NULL COMMENT 'CSV Yes=1, No=0',
    eta_variance_minutes     INT           NOT NULL,
    delay_reason             VARCHAR(30)   NOT NULL COMMENT 'literal "None" = no delay (source value)',
    delivery_attempts        INT           NOT NULL,
    speed_kmph               DECIMAL(6,1)  NOT NULL,
    fuel_level_pct           DECIMAL(5,1)  NOT NULL,
    route_condition          VARCHAR(20)   NOT NULL,
    traffic_level            VARCHAR(20)   NOT NULL,
    package_weight_kg        DECIMAL(8,2)  NOT NULL,

    -- ---- derived by processor.py (documented, never overwrite source) ----
    order_ts                 DATETIME      NOT NULL COMMENT 'order_date + order_time (event time, IST wall clock as in CSV)',
    load_utilization_pct     DECIMAL(6,2)  NOT NULL COMMENT 'DERIVED: package_weight_kg / vehicle_capacity_kg * 100',

    -- ---- streaming metadata ----
    produced_at              DATETIME(3)   NULL     COMMENT 'UTC, when producer sent the event',
    ingested_at              DATETIME(3)   NOT NULL COMMENT 'UTC, when processor wrote the row',
    kafka_partition          INT           NOT NULL,
    kafka_offset             BIGINT        NOT NULL,

    PRIMARY KEY (event_id),
    UNIQUE KEY uq_run_pass_order (run_id, pass_no, order_id),
    KEY idx_run_ingested (run_id, ingested_at),
    KEY idx_run_city (run_id, region, city),
    KEY idx_run_status (run_id, order_status),
    KEY idx_run_orderdate (run_id, order_date),
    CONSTRAINT chk_sla_flag  CHECK (sla_breach IN (0,1)),
    CONSTRAINT chk_risk_flag CHECK (at_risk IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Events that failed validation. Nothing is silently dropped.
CREATE TABLE IF NOT EXISTS rejected_events (
    id                 BIGINT        NOT NULL AUTO_INCREMENT,
    run_id             VARCHAR(64)   NOT NULL,
    pass_no            INT           NOT NULL DEFAULT 1,
    order_id           VARCHAR(64)   NULL,
    source_row_number  INT           NULL,
    kafka_partition    INT           NOT NULL,
    kafka_offset       BIGINT        NOT NULL,
    reason             VARCHAR(500)  NOT NULL,
    raw_payload        MEDIUMTEXT    NOT NULL,
    rejected_at        DATETIME(3)   NOT NULL COMMENT 'UTC',
    PRIMARY KEY (id),
    UNIQUE KEY uq_rejected_msg (run_id, kafka_partition, kafka_offset),
    KEY idx_rejected_run (run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
